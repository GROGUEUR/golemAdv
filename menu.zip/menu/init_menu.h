#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_mixer.h>

// Dimensions de la fenêtre
#define WINDOW_WIDTH 1280
#define WINDOW_HEIGHT 720

// Constantes de sortie du menu
#define PLAY 1
#define SETTINGS 2
#define CREDITS 3

// Structure pour stocker les informations sur une image
typedef struct {
    SDL_Texture *texture;
    SDL_Rect rect;
} Image;

// Fonction pour charger une image
SDL_Texture* loadTexture(SDL_Renderer*, const char*);

// Fonctions des menus
int menuPrincipal();
int menuPlay();
