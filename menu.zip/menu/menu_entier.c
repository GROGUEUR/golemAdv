#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_mixer.h>
#include <stdbool.h>
#include <stdlib.h>
#include "init_menu.h"

int main(){
	// Déclarations
	SDL_Window *window;
	SDL_Renderer *renderer;
	int ecranTitreChoix = 0;
	
	// Initialisation SDL
	if (SDL_Init(SDL_INIT_VIDEO) != 0) {
		printf("Erreur lors de l'initialisation de SDL : %s\n", SDL_GetError());
		return 1;
	}

	// Cration de la fentre
	window = SDL_CreateWindow("SDL Image Example", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, WINDOW_WIDTH, WINDOW_HEIGHT, 0);
	if (!window) {
		printf("Erreur lors de la cration de la fentre : %s\n", SDL_GetError());
		SDL_Quit();
		return 1;
	}

	// Cration du renderer
	renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
	if (!renderer) {
		printf("Erreur lors de la cration du renderer : %s\n", SDL_GetError());
		SDL_DestroyWindow(window);
		SDL_Quit();
		return 1;
	}
	
	while(ecranTitreChoix != SETTINGS && ecranTitreChoix != CREDITS){
		ecranTitreChoix = menuPrincipal(window, renderer);
		if(ecranTitreChoix == PLAY)
			menuPlay(window, renderer);
		else if(ecranTitreChoix == SETTINGS){}
		else if(ecranTitreChoix == CREDITS){}
	}
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	SDL_Quit();
	
	return 0;
}
