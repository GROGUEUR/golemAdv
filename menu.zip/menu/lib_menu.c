#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_mixer.h>
#include <stdbool.h>
#include <stdlib.h>
#include "init_menu.h"

// Fonction pour charger une image
SDL_Texture* loadTexture(SDL_Renderer* renderer, const char* chemin) {
	SDL_Surface* surface = IMG_Load(chemin);
	if (!surface) {
		fprintf(stderr, "Erreur lors du chargement de l'image : %s\n", IMG_GetError());
		return NULL;
	}

	SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);
	SDL_FreeSurface(surface);

	if (!texture) {
		fprintf(stderr, "Erreur 1 lors de la création de la texture : %s\n", SDL_GetError());
		return NULL;
	}

	return texture;
}

// Menu principal
int menuPrincipal(SDL_Window *window, SDL_Renderer *renderer) {
	SDL_Event event;
	bool quit = false;
	bool hoverPlay = false, hoverSettings = false, hoverCredits = false;
	bool clickedPlay = false, clickedSettings = false, clickedCredits = false;
	int choix;

	// Chargement de l'image Play par defaut
	Image defaultPlayImage;
	defaultPlayImage.texture = loadTexture(renderer, "assets/defaultPlay.jpg");
	if (!defaultPlayImage.texture) {
		SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		SDL_Quit();
		return 0;
	}
	SDL_QueryTexture(defaultPlayImage.texture, NULL, NULL, &defaultPlayImage.rect.w, &defaultPlayImage.rect.h);
	defaultPlayImage.rect.x = (WINDOW_WIDTH - defaultPlayImage.rect.w) / 2;
	defaultPlayImage.rect.y = (WINDOW_HEIGHT - defaultPlayImage.rect.h - 300) / 2;

	// Chargement de l'image Settings par defaut
	Image defaultSettingsImage;
	defaultSettingsImage.texture = loadTexture(renderer, "assets/defaultSettings.jpg");
	if (!defaultSettingsImage.texture) {
		SDL_DestroyTexture(defaultPlayImage.texture);
		SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		SDL_Quit();
		return 0;
	}
	SDL_QueryTexture(defaultSettingsImage.texture, NULL, NULL, &defaultSettingsImage.rect.w, &defaultSettingsImage.rect.h);
	defaultSettingsImage.rect.x = (WINDOW_WIDTH - defaultSettingsImage.rect.w) / 2;
	defaultSettingsImage.rect.y = (WINDOW_HEIGHT - defaultSettingsImage.rect.h) / 2;

	// Chargement de l'image Credits par defaut
	Image defaultCreditsImage;
	defaultCreditsImage.texture = loadTexture(renderer, "assets/defaultCredits.jpg");
	if (!defaultCreditsImage.texture) {
		SDL_DestroyTexture(defaultPlayImage.texture);
		SDL_DestroyTexture(defaultSettingsImage.texture);
		SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		SDL_Quit();
		return 0;
	}
	SDL_QueryTexture(defaultCreditsImage.texture, NULL, NULL, &defaultCreditsImage.rect.w, &defaultCreditsImage.rect.h);
	defaultCreditsImage.rect.x = (WINDOW_WIDTH - defaultCreditsImage.rect.w) / 2;
	defaultCreditsImage.rect.y = (WINDOW_HEIGHT - defaultCreditsImage.rect.h + 300) / 2;

	// Chargement de l'image Play du survol
	Image hoverPlayImage;
	hoverPlayImage.texture = loadTexture(renderer, "assets/hoverPlay.jpg");
	if (!hoverPlayImage.texture) {
		SDL_DestroyTexture(defaultPlayImage.texture);
		SDL_DestroyTexture(defaultSettingsImage.texture);
		SDL_DestroyTexture(defaultCreditsImage.texture);
		SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		SDL_Quit();
		return 0;
	}
	SDL_QueryTexture(hoverPlayImage.texture, NULL, NULL, &hoverPlayImage.rect.w, &hoverPlayImage.rect.h);
	hoverPlayImage.rect.x = (WINDOW_WIDTH - hoverPlayImage.rect.w) / 2;
	hoverPlayImage.rect.y = (WINDOW_HEIGHT - hoverPlayImage.rect.h - 300) / 2;

	// Chargement de l'image Settings du survol
	Image hoverSettingsImage;
	hoverSettingsImage.texture = loadTexture(renderer, "assets/hoverSettings.jpg");
	if (!hoverSettingsImage.texture) {
		SDL_DestroyTexture(defaultPlayImage.texture);
		SDL_DestroyTexture(defaultSettingsImage.texture);
		SDL_DestroyTexture(defaultCreditsImage.texture);
		SDL_DestroyTexture(hoverPlayImage.texture);
		SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		SDL_Quit();
		return 0;
	}
	SDL_QueryTexture(hoverSettingsImage.texture, NULL, NULL, &hoverSettingsImage.rect.w, &hoverSettingsImage.rect.h);
	hoverSettingsImage.rect.x = (WINDOW_WIDTH - hoverSettingsImage.rect.w) / 2;
	hoverSettingsImage.rect.y = (WINDOW_HEIGHT - hoverSettingsImage.rect.h) / 2;

	// Chargement de l'image Credits du survol
	Image hoverCreditsImage;
	hoverCreditsImage.texture = loadTexture(renderer, "assets/hoverCredits.jpg");
	if (!hoverCreditsImage.texture) {
		SDL_DestroyTexture(defaultPlayImage.texture);
		SDL_DestroyTexture(defaultSettingsImage.texture);
		SDL_DestroyTexture(defaultCreditsImage.texture);
		SDL_DestroyTexture(hoverPlayImage.texture);
		SDL_DestroyTexture(hoverSettingsImage.texture);
		SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		SDL_Quit();
		return 0;
	}
	SDL_QueryTexture(hoverCreditsImage.texture, NULL, NULL, &hoverCreditsImage.rect.w, &hoverCreditsImage.rect.h);
	hoverCreditsImage.rect.x = (WINDOW_WIDTH - hoverCreditsImage.rect.w) / 2;
	hoverCreditsImage.rect.y = (WINDOW_HEIGHT - hoverCreditsImage.rect.h + 300) / 2;

	// Chargement de l'image Play lors du clic
	Image clickedPlayImage;
	clickedPlayImage.texture = loadTexture(renderer, "assets/clickedPlay.jpg");
	if (!clickedPlayImage.texture) {
		SDL_DestroyTexture(defaultPlayImage.texture);
		SDL_DestroyTexture(defaultSettingsImage.texture);
		SDL_DestroyTexture(defaultCreditsImage.texture);
		SDL_DestroyTexture(hoverPlayImage.texture);
		SDL_DestroyTexture(hoverSettingsImage.texture);
		SDL_DestroyTexture(hoverCreditsImage.texture);
		SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		SDL_Quit();
		return 0;
	}
	SDL_QueryTexture(clickedPlayImage.texture, NULL, NULL, &clickedPlayImage.rect.w, &clickedPlayImage.rect.h);
	clickedPlayImage.rect.x = (WINDOW_WIDTH - clickedPlayImage.rect.w) / 2;
	clickedPlayImage.rect.y = (WINDOW_HEIGHT - clickedPlayImage.rect.h - 300) / 2;

	// Chargement de l'image Settings lors du clic
	Image clickedSettingsImage;
	clickedSettingsImage.texture = loadTexture(renderer, "assets/clickedSettings.jpg");
	if (!clickedSettingsImage.texture) {
		SDL_DestroyTexture(defaultPlayImage.texture);
		SDL_DestroyTexture(defaultSettingsImage.texture);
		SDL_DestroyTexture(defaultCreditsImage.texture);
		SDL_DestroyTexture(hoverPlayImage.texture);
		SDL_DestroyTexture(hoverSettingsImage.texture);
		SDL_DestroyTexture(hoverCreditsImage.texture);
		SDL_DestroyTexture(clickedPlayImage.texture);
		SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		SDL_Quit();
		return 0;
	}
	SDL_QueryTexture(clickedSettingsImage.texture, NULL, NULL, &clickedSettingsImage.rect.w, &clickedSettingsImage.rect.h);
	clickedSettingsImage.rect.x = (WINDOW_WIDTH - clickedSettingsImage.rect.w) / 2;
	clickedSettingsImage.rect.y = (WINDOW_HEIGHT - clickedSettingsImage.rect.h) / 2;

	// Chargement de l'image Credits lors du clic
	Image clickedCreditsImage;
	clickedCreditsImage.texture = loadTexture(renderer, "assets/clickedCredits.jpg");
	if (!clickedCreditsImage.texture) {
		SDL_DestroyTexture(defaultPlayImage.texture);
		SDL_DestroyTexture(defaultSettingsImage.texture);
		SDL_DestroyTexture(defaultCreditsImage.texture);
		SDL_DestroyTexture(hoverPlayImage.texture);
		SDL_DestroyTexture(hoverSettingsImage.texture);
		SDL_DestroyTexture(hoverCreditsImage.texture);
		SDL_DestroyTexture(clickedPlayImage.texture);
		SDL_DestroyTexture(clickedSettingsImage.texture);
		SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		SDL_Quit();
		return 0;
	}
	SDL_QueryTexture(clickedCreditsImage.texture, NULL, NULL, &clickedCreditsImage.rect.w, &clickedCreditsImage.rect.h);
	clickedCreditsImage.rect.x = (WINDOW_WIDTH - clickedCreditsImage.rect.w) / 2;
	clickedCreditsImage.rect.y = (WINDOW_HEIGHT - clickedCreditsImage.rect.h + 300) / 2;

	// condition d'arret : chargement d'une sauvegarde (vide ou commencée)
	while (!quit) {
		while (SDL_PollEvent(&event)) {
			switch (event.type) {
				case SDL_QUIT:
					quit = true;
					break;
				case SDL_MOUSEMOTION:
					if (event.motion.x >= defaultPlayImage.rect.x && event.motion.x <= defaultPlayImage.rect.x + defaultPlayImage.rect.w &&
					event.motion.y >= defaultPlayImage.rect.y && event.motion.y <= defaultPlayImage.rect.y + defaultPlayImage.rect.h) {
						hoverPlay = true;
						hoverSettings = false;
						hoverCredits = false;
					}
					else if (event.motion.x >= defaultSettingsImage.rect.x && event.motion.x <= defaultSettingsImage.rect.x + defaultSettingsImage.rect.w &&
					event.motion.y >= defaultSettingsImage.rect.y && event.motion.y <= defaultSettingsImage.rect.y + defaultSettingsImage.rect.h) {
						hoverPlay = false;
						hoverSettings = true;
						hoverCredits = false;
					}
					else if (event.motion.x >= defaultCreditsImage.rect.x && event.motion.x <= defaultCreditsImage.rect.x + defaultCreditsImage.rect.w &&
					event.motion.y >= defaultCreditsImage.rect.y && event.motion.y <= defaultCreditsImage.rect.y + defaultCreditsImage.rect.h) {
						hoverPlay = false;
						hoverSettings = false;
						hoverCredits = true;
					}
					else {
						hoverPlay = false;
						clickedPlay = false;
						hoverSettings = false;
						clickedSettings = false;
						hoverCredits = false;
						clickedCredits = false;
					}
					break;
				case SDL_MOUSEBUTTONDOWN:
					if (event.button.button == SDL_BUTTON_LEFT && hoverPlay)
						clickedPlay = true;
					else if (event.button.button == SDL_BUTTON_LEFT && hoverSettings)
						clickedSettings = true;
					else if (event.button.button == SDL_BUTTON_LEFT && hoverCredits)
						clickedCredits = true;
					break;
				case SDL_MOUSEBUTTONUP:
					if(hoverPlay){
						clickedPlay = false;
						// INSERER ACTIONS DU CLIC ICI
						choix = PLAY;
						quit = true;
					}
					else if(hoverSettings){
						clickedSettings = false;
						// INSERER ACTIONS DU CLIC ICI
						choix = SETTINGS;
					}
					else if(hoverCredits){
						clickedCredits = false;
						// INSERER ACTIONS DU CLIC ICI
						choix = CREDITS;
					}
					break;
			}
		}

		// Effacement de l'cran
		SDL_RenderClear(renderer);

		// Affichage de l'image appropriée
		if (clickedPlay)
			SDL_RenderCopy(renderer, clickedPlayImage.texture, NULL, &clickedPlayImage.rect);
		else if (hoverPlay)
			SDL_RenderCopy(renderer, hoverPlayImage.texture, NULL, &hoverPlayImage.rect);
		else if (!clickedPlay && !hoverPlay)
			SDL_RenderCopy(renderer, defaultPlayImage.texture, NULL, &defaultPlayImage.rect);
		if (clickedSettings)
			SDL_RenderCopy(renderer, clickedSettingsImage.texture, NULL, &clickedSettingsImage.rect);
		else if (hoverSettings)
			SDL_RenderCopy(renderer, hoverSettingsImage.texture, NULL, &hoverSettingsImage.rect);
		else if (!clickedSettings && !hoverSettings)
			SDL_RenderCopy(renderer, defaultSettingsImage.texture, NULL, &defaultSettingsImage.rect);
		if (clickedCredits)
			SDL_RenderCopy(renderer, clickedCreditsImage.texture, NULL, &clickedCreditsImage.rect);
		else if (hoverCredits)
			SDL_RenderCopy(renderer, hoverCreditsImage.texture, NULL, &hoverCreditsImage.rect);
		else if (!clickedCredits && !hoverCredits)
			SDL_RenderCopy(renderer, defaultCreditsImage.texture, NULL, &defaultCreditsImage.rect);

		// Affichage sur l'cran
		SDL_RenderPresent(renderer);
	}
	
	// Libration des ressources
	SDL_DestroyTexture(defaultPlayImage.texture);
	SDL_DestroyTexture(hoverPlayImage.texture);
	SDL_DestroyTexture(clickedPlayImage.texture);
	SDL_DestroyTexture(defaultSettingsImage.texture);
	SDL_DestroyTexture(hoverSettingsImage.texture);
	SDL_DestroyTexture(clickedSettingsImage.texture);
	SDL_DestroyTexture(defaultCreditsImage.texture);
	SDL_DestroyTexture(hoverCreditsImage.texture);
	SDL_DestroyTexture(clickedCreditsImage.texture);
	
	return choix;
}

// Menu PLAY
int menuPlay(SDL_Window *window, SDL_Renderer *renderer) {
	SDL_Event event;
	FILE *save1 = fopen("save1.txt", "r");
	FILE *save2 = fopen("save2.txt", "r");
	FILE *save3 = fopen("save3.txt", "r");
	bool quit = false;
	bool hoverSave1 = false, hoverSave2 = false, hoverSave3 = false, hoverStart = false, hoverOverwrite = false, hoverBack = false;
	bool clickedSave1 = false, clickedSave2 = false, clickedSave3 = false, clickedStart = false, clickedOverwrite = false, clickedBack = false;
	
	// Chargement de l'image de la sauvegarde 1 par défaut
	Image defaultSave1Image;
	defaultSave1Image.texture = loadTexture(renderer, "assets/defaultSave.png");
	if (!defaultSave1Image.texture) {
		SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		SDL_Quit();
		return 0;
	}
	SDL_QueryTexture(defaultSave1Image.texture, NULL, NULL, &defaultSave1Image.rect.w, &defaultSave1Image.rect.h);
	defaultSave1Image.rect.x = 75;
	defaultSave1Image.rect.y = 75;
	
	// Chargement de l'image de la sauvegarde 2 par défaut
	Image defaultSave2Image;
	defaultSave2Image.texture = loadTexture(renderer, "assets/defaultSave.png");
	if (!defaultSave2Image.texture) {
		SDL_DestroyTexture(defaultSave1Image.texture);
		SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		SDL_Quit();
		return 0;
	}
	SDL_QueryTexture(defaultSave2Image.texture, NULL, NULL, &defaultSave2Image.rect.w, &defaultSave2Image.rect.h);
	defaultSave2Image.rect.x = 75;
	defaultSave2Image.rect.y = 285;
	
	// Chargement de l'image de la sauvegarde 3 par défaut
	Image defaultSave3Image;
	defaultSave3Image.texture = loadTexture(renderer, "assets/defaultSave.png");
	if (!defaultSave3Image.texture) {
		SDL_DestroyTexture(defaultSave1Image.texture);
		SDL_DestroyTexture(defaultSave2Image.texture);
		SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		SDL_Quit();
		return 0;
	}
	SDL_QueryTexture(defaultSave3Image.texture, NULL, NULL, &defaultSave3Image.rect.w, &defaultSave3Image.rect.h);
	defaultSave3Image.rect.x = 75;
	defaultSave3Image.rect.y = 495;
	
	// Chargement de l'image de la sauvegarde 1 au survol
	Image hoverSave1Image;
	hoverSave1Image.texture = loadTexture(renderer, "assets/hoverSave.png");
	if (!hoverSave1Image.texture) {
		SDL_DestroyTexture(defaultSave1Image.texture);
		SDL_DestroyTexture(defaultSave2Image.texture);
		SDL_DestroyTexture(defaultSave3Image.texture);
		SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		SDL_Quit();
		return 0;
	}
	SDL_QueryTexture(hoverSave1Image.texture, NULL, NULL, &hoverSave1Image.rect.w, &hoverSave1Image.rect.h);
	hoverSave1Image.rect.x = 75;
	hoverSave1Image.rect.y = 75;
	
	// Chargement de l'image de la sauvegarde 2 au survol
	Image hoverSave2Image;
	hoverSave2Image.texture = loadTexture(renderer, "assets/hoverSave.png");
	if (!hoverSave2Image.texture) {
		SDL_DestroyTexture(defaultSave1Image.texture);
		SDL_DestroyTexture(defaultSave2Image.texture);
		SDL_DestroyTexture(defaultSave3Image.texture);
		SDL_DestroyTexture(hoverSave1Image.texture);
		SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		SDL_Quit();
		return 0;
	}
	SDL_QueryTexture(hoverSave2Image.texture, NULL, NULL, &hoverSave2Image.rect.w, &hoverSave2Image.rect.h);
	hoverSave2Image.rect.x = 75;
	hoverSave2Image.rect.y = 285;
	
	// Chargement de l'image de la sauvegarde 3 au survol
	Image hoverSave3Image;
	hoverSave3Image.texture = loadTexture(renderer, "assets/hoverSave.png");
	if (!hoverSave3Image.texture) {
		SDL_DestroyTexture(defaultSave1Image.texture);
		SDL_DestroyTexture(defaultSave2Image.texture);
		SDL_DestroyTexture(defaultSave3Image.texture);
		SDL_DestroyTexture(hoverSave1Image.texture);
		SDL_DestroyTexture(hoverSave2Image.texture);
		SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		SDL_Quit();
		return 0;
	}
	SDL_QueryTexture(hoverSave3Image.texture, NULL, NULL, &hoverSave3Image.rect.w, &hoverSave3Image.rect.h);
	hoverSave3Image.rect.x = 75;
	hoverSave3Image.rect.y = 495;
	
	// Chargement de l'image de la sauvegarde 1 au clic
	Image clickedSave1Image;
	clickedSave1Image.texture = loadTexture(renderer, "assets/clickedSave.png");
	if (!clickedSave1Image.texture) {
		SDL_DestroyTexture(defaultSave1Image.texture);
		SDL_DestroyTexture(defaultSave2Image.texture);
		SDL_DestroyTexture(defaultSave3Image.texture);
		SDL_DestroyTexture(hoverSave1Image.texture);
		SDL_DestroyTexture(hoverSave2Image.texture);
		SDL_DestroyTexture(hoverSave3Image.texture);
		SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		SDL_Quit();
		return 0;
	}
	SDL_QueryTexture(clickedSave1Image.texture, NULL, NULL, &clickedSave1Image.rect.w, &clickedSave1Image.rect.h);
	clickedSave1Image.rect.x = 75;
	clickedSave1Image.rect.y = 75;
	
	// Chargement de l'image de la sauvegarde 2 au clic
	Image clickedSave2Image;
	clickedSave2Image.texture = loadTexture(renderer, "assets/clickedSave.png");
	if (!clickedSave2Image.texture) {
		SDL_DestroyTexture(defaultSave1Image.texture);
		SDL_DestroyTexture(defaultSave2Image.texture);
		SDL_DestroyTexture(defaultSave3Image.texture);
		SDL_DestroyTexture(hoverSave1Image.texture);
		SDL_DestroyTexture(hoverSave2Image.texture);
		SDL_DestroyTexture(hoverSave3Image.texture);
		SDL_DestroyTexture(clickedSave1Image.texture);
		SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		SDL_Quit();
		return 0;
	}
	SDL_QueryTexture(clickedSave2Image.texture, NULL, NULL, &clickedSave2Image.rect.w, &clickedSave2Image.rect.h);
	clickedSave2Image.rect.x = 75;
	clickedSave2Image.rect.y = 285;
	
	// Chargement de l'image de la sauvegarde 3 au clic
	Image clickedSave3Image;
	clickedSave3Image.texture = loadTexture(renderer, "assets/clickedSave.png");
	if (!clickedSave3Image.texture) {
		SDL_DestroyTexture(defaultSave1Image.texture);
		SDL_DestroyTexture(defaultSave2Image.texture);
		SDL_DestroyTexture(defaultSave3Image.texture);
		SDL_DestroyTexture(hoverSave1Image.texture);
		SDL_DestroyTexture(hoverSave2Image.texture);
		SDL_DestroyTexture(hoverSave3Image.texture);
		SDL_DestroyTexture(clickedSave1Image.texture);
		SDL_DestroyTexture(clickedSave2Image.texture);
		SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		SDL_Quit();
		return 0;
	}
	SDL_QueryTexture(clickedSave3Image.texture, NULL, NULL, &clickedSave3Image.rect.w, &clickedSave3Image.rect.h);
	clickedSave3Image.rect.x = 75;
	clickedSave3Image.rect.y = 495;
	
	// Chargement de l'image de l'option lancement par défaut
	Image defaultStartImage;
	defaultStartImage.texture = loadTexture(renderer, "assets/defaultOption.png");
	if (!defaultStartImage.texture) {
		SDL_DestroyTexture(defaultSave1Image.texture);
		SDL_DestroyTexture(defaultSave2Image.texture);
		SDL_DestroyTexture(defaultSave3Image.texture);
		SDL_DestroyTexture(hoverSave1Image.texture);
		SDL_DestroyTexture(hoverSave2Image.texture);
		SDL_DestroyTexture(hoverSave3Image.texture);
		SDL_DestroyTexture(clickedSave1Image.texture);
		SDL_DestroyTexture(clickedSave2Image.texture);
		SDL_DestroyTexture(clickedSave3Image.texture);
		SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		SDL_Quit();
		return 0;
	}
	SDL_QueryTexture(defaultStartImage.texture, NULL, NULL, &defaultStartImage.rect.w, &defaultStartImage.rect.h);
	defaultStartImage.rect.x = 1000;
	defaultStartImage.rect.y = 75;
	
	// Chargement de l'image de l'option écrasement par défaut
	Image defaultOverwriteImage;
	defaultOverwriteImage.texture = loadTexture(renderer, "assets/defaultOption.png");
	if (!defaultOverwriteImage.texture) {
		SDL_DestroyTexture(defaultSave1Image.texture);
		SDL_DestroyTexture(defaultSave2Image.texture);
		SDL_DestroyTexture(defaultSave3Image.texture);
		SDL_DestroyTexture(hoverSave1Image.texture);
		SDL_DestroyTexture(hoverSave2Image.texture);
		SDL_DestroyTexture(hoverSave3Image.texture);
		SDL_DestroyTexture(clickedSave1Image.texture);
		SDL_DestroyTexture(clickedSave2Image.texture);
		SDL_DestroyTexture(clickedSave3Image.texture);
		SDL_DestroyTexture(defaultStartImage.texture);
		SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		SDL_Quit();
		return 0;
	}
	SDL_QueryTexture(defaultOverwriteImage.texture, NULL, NULL, &defaultOverwriteImage.rect.w, &defaultOverwriteImage.rect.h);
	defaultOverwriteImage.rect.x = 1000;
	defaultOverwriteImage.rect.y = 285;
	
	// Chargement de l'image de l'option retour par défaut
	Image defaultBackImage;
	defaultBackImage.texture = loadTexture(renderer, "assets/defaultOption.png");
	if (!defaultBackImage.texture) {
		SDL_DestroyTexture(defaultSave1Image.texture);
		SDL_DestroyTexture(defaultSave2Image.texture);
		SDL_DestroyTexture(defaultSave3Image.texture);
		SDL_DestroyTexture(hoverSave1Image.texture);
		SDL_DestroyTexture(hoverSave2Image.texture);
		SDL_DestroyTexture(hoverSave3Image.texture);
		SDL_DestroyTexture(clickedSave1Image.texture);
		SDL_DestroyTexture(clickedSave2Image.texture);
		SDL_DestroyTexture(clickedSave3Image.texture);
		SDL_DestroyTexture(defaultStartImage.texture);
		SDL_DestroyTexture(defaultOverwriteImage.texture);
		SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		SDL_Quit();
		return 0;
	}
	SDL_QueryTexture(defaultBackImage.texture, NULL, NULL, &defaultBackImage.rect.w, &defaultBackImage.rect.h);
	defaultBackImage.rect.x = 1000;
	defaultBackImage.rect.y = 495;
	
	// Chargement de l'image de l'option lancement au survol
	Image hoverStartImage;
	hoverStartImage.texture = loadTexture(renderer, "assets/hoverOption.png");
	if (!hoverStartImage.texture) {
		SDL_DestroyTexture(defaultSave1Image.texture);
		SDL_DestroyTexture(defaultSave2Image.texture);
		SDL_DestroyTexture(defaultSave3Image.texture);
		SDL_DestroyTexture(hoverSave1Image.texture);
		SDL_DestroyTexture(hoverSave2Image.texture);
		SDL_DestroyTexture(hoverSave3Image.texture);
		SDL_DestroyTexture(clickedSave1Image.texture);
		SDL_DestroyTexture(clickedSave2Image.texture);
		SDL_DestroyTexture(clickedSave3Image.texture);
		SDL_DestroyTexture(defaultStartImage.texture);
		SDL_DestroyTexture(defaultOverwriteImage.texture);
		SDL_DestroyTexture(defaultBackImage.texture);
		SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		SDL_Quit();
		return 0;
	}
	SDL_QueryTexture(hoverStartImage.texture, NULL, NULL, &hoverStartImage.rect.w, &hoverStartImage.rect.h);
	hoverStartImage.rect.x = 1000;
	hoverStartImage.rect.y = 75;
	
	// Chargement de l'image de l'option écrasement au survol
	Image hoverOverwriteImage;
	hoverOverwriteImage.texture = loadTexture(renderer, "assets/hoverOption.png");
	if (!hoverOverwriteImage.texture) {
		SDL_DestroyTexture(defaultSave1Image.texture);
		SDL_DestroyTexture(defaultSave2Image.texture);
		SDL_DestroyTexture(defaultSave3Image.texture);
		SDL_DestroyTexture(hoverSave1Image.texture);
		SDL_DestroyTexture(hoverSave2Image.texture);
		SDL_DestroyTexture(hoverSave3Image.texture);
		SDL_DestroyTexture(clickedSave1Image.texture);
		SDL_DestroyTexture(clickedSave2Image.texture);
		SDL_DestroyTexture(clickedSave3Image.texture);
		SDL_DestroyTexture(defaultStartImage.texture);
		SDL_DestroyTexture(defaultOverwriteImage.texture);
		SDL_DestroyTexture(defaultBackImage.texture);
		SDL_DestroyTexture(hoverStartImage.texture);
		SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		SDL_Quit();
		return 0;
	}
	SDL_QueryTexture(hoverOverwriteImage.texture, NULL, NULL, &hoverOverwriteImage.rect.w, &hoverOverwriteImage.rect.h);
	hoverOverwriteImage.rect.x = 1000;
	hoverOverwriteImage.rect.y = 285;
	
	// Chargement de l'image de l'option retour au survol
	Image hoverBackImage;
	hoverBackImage.texture = loadTexture(renderer, "assets/hoverOption.png");
	if (!hoverBackImage.texture) {
		SDL_DestroyTexture(defaultSave1Image.texture);
		SDL_DestroyTexture(defaultSave2Image.texture);
		SDL_DestroyTexture(defaultSave3Image.texture);
		SDL_DestroyTexture(hoverSave1Image.texture);
		SDL_DestroyTexture(hoverSave2Image.texture);
		SDL_DestroyTexture(hoverSave3Image.texture);
		SDL_DestroyTexture(clickedSave1Image.texture);
		SDL_DestroyTexture(clickedSave2Image.texture);
		SDL_DestroyTexture(clickedSave3Image.texture);
		SDL_DestroyTexture(defaultStartImage.texture);
		SDL_DestroyTexture(defaultOverwriteImage.texture);
		SDL_DestroyTexture(defaultBackImage.texture);
		SDL_DestroyTexture(hoverStartImage.texture);
		SDL_DestroyTexture(hoverOverwriteImage.texture);
		SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		SDL_Quit();
		return 0;
	}
	SDL_QueryTexture(hoverBackImage.texture, NULL, NULL, &hoverBackImage.rect.w, &hoverBackImage.rect.h);
	hoverBackImage.rect.x = 1000;
	hoverBackImage.rect.y = 495;
	
	// Chargement de l'image de l'option lancement au clic
	Image clickedStartImage;
	clickedStartImage.texture = loadTexture(renderer, "assets/clickedOption.png");
	if (!clickedStartImage.texture) {
		SDL_DestroyTexture(defaultSave1Image.texture);
		SDL_DestroyTexture(defaultSave2Image.texture);
		SDL_DestroyTexture(defaultSave3Image.texture);
		SDL_DestroyTexture(hoverSave1Image.texture);
		SDL_DestroyTexture(hoverSave2Image.texture);
		SDL_DestroyTexture(hoverSave3Image.texture);
		SDL_DestroyTexture(clickedSave1Image.texture);
		SDL_DestroyTexture(clickedSave2Image.texture);
		SDL_DestroyTexture(clickedSave3Image.texture);
		SDL_DestroyTexture(defaultStartImage.texture);
		SDL_DestroyTexture(defaultOverwriteImage.texture);
		SDL_DestroyTexture(defaultBackImage.texture);
		SDL_DestroyTexture(hoverStartImage.texture);
		SDL_DestroyTexture(hoverOverwriteImage.texture);
		SDL_DestroyTexture(hoverBackImage.texture);
		SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		SDL_Quit();
		return 0;
	}
	SDL_QueryTexture(clickedStartImage.texture, NULL, NULL, &clickedStartImage.rect.w, &clickedStartImage.rect.h);
	clickedStartImage.rect.x = 1000;
	clickedStartImage.rect.y = 75;
	
	// Chargement de l'image de l'option écrasement au clic
	Image clickedOverwriteImage;
	clickedOverwriteImage.texture = loadTexture(renderer, "assets/clickedOption.png");
	if (!clickedOverwriteImage.texture) {
		SDL_DestroyTexture(defaultSave1Image.texture);
		SDL_DestroyTexture(defaultSave2Image.texture);
		SDL_DestroyTexture(defaultSave3Image.texture);
		SDL_DestroyTexture(hoverSave1Image.texture);
		SDL_DestroyTexture(hoverSave2Image.texture);
		SDL_DestroyTexture(hoverSave3Image.texture);
		SDL_DestroyTexture(clickedSave1Image.texture);
		SDL_DestroyTexture(clickedSave2Image.texture);
		SDL_DestroyTexture(clickedSave3Image.texture);
		SDL_DestroyTexture(defaultStartImage.texture);
		SDL_DestroyTexture(defaultOverwriteImage.texture);
		SDL_DestroyTexture(defaultBackImage.texture);
		SDL_DestroyTexture(hoverStartImage.texture);
		SDL_DestroyTexture(hoverOverwriteImage.texture);
		SDL_DestroyTexture(hoverBackImage.texture);
		SDL_DestroyTexture(clickedStartImage.texture);
		SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		SDL_Quit();
		return 0;
	}
	SDL_QueryTexture(clickedOverwriteImage.texture, NULL, NULL, &clickedOverwriteImage.rect.w, &clickedOverwriteImage.rect.h);
	clickedOverwriteImage.rect.x = 1000;
	clickedOverwriteImage.rect.y = 285;
	
	// Chargement de l'image de l'option retour au clic
	Image clickedBackImage;
	clickedBackImage.texture = loadTexture(renderer, "assets/clickedOption.png");
	if (!clickedBackImage.texture) {
		SDL_DestroyTexture(defaultSave1Image.texture);
		SDL_DestroyTexture(defaultSave2Image.texture);
		SDL_DestroyTexture(defaultSave3Image.texture);
		SDL_DestroyTexture(hoverSave1Image.texture);
		SDL_DestroyTexture(hoverSave2Image.texture);
		SDL_DestroyTexture(hoverSave3Image.texture);
		SDL_DestroyTexture(clickedSave1Image.texture);
		SDL_DestroyTexture(clickedSave2Image.texture);
		SDL_DestroyTexture(clickedSave3Image.texture);
		SDL_DestroyTexture(defaultStartImage.texture);
		SDL_DestroyTexture(defaultOverwriteImage.texture);
		SDL_DestroyTexture(defaultBackImage.texture);
		SDL_DestroyTexture(hoverStartImage.texture);
		SDL_DestroyTexture(hoverOverwriteImage.texture);
		SDL_DestroyTexture(hoverBackImage.texture);
		SDL_DestroyTexture(clickedStartImage.texture);
		SDL_DestroyTexture(clickedOverwriteImage.texture);
		SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		SDL_Quit();
		return 0;
	}
	SDL_QueryTexture(clickedBackImage.texture, NULL, NULL, &clickedBackImage.rect.w, &clickedBackImage.rect.h);
	clickedBackImage.rect.x = 1000;
	clickedBackImage.rect.y = 495;
	
	// condition d'arret : chargement d'une sauvegarde (vide ou commencée)
	while (!quit) {
		while (SDL_PollEvent(&event)) {
			switch (event.type) {
				case SDL_QUIT:
					quit = true;
					break;
				case SDL_MOUSEMOTION:
					if (event.motion.x >= defaultSave1Image.rect.x && event.motion.x <= defaultSave1Image.rect.x + defaultSave1Image.rect.w &&
					event.motion.y >= defaultSave1Image.rect.y && event.motion.y <= defaultSave1Image.rect.y + defaultSave1Image.rect.h) {
						hoverSave1 = true;
						hoverSave2 = false;
						hoverSave3 = false;
						hoverStart = false;
						hoverOverwrite = false;
						hoverBack = false;
					}
					else if (event.motion.x >= defaultSave2Image.rect.x && event.motion.x <= defaultSave2Image.rect.x + defaultSave2Image.rect.w &&
					event.motion.y >= defaultSave2Image.rect.y && event.motion.y <= defaultSave2Image.rect.y + defaultSave2Image.rect.h) {
						hoverSave1 = false;
						hoverSave2 = true;
						hoverSave3 = false;
						hoverStart = false;
						hoverOverwrite = false;
						hoverBack = false;
					}
					else if (event.motion.x >= defaultSave3Image.rect.x && event.motion.x <= defaultSave3Image.rect.x + defaultSave3Image.rect.w &&
					event.motion.y >= defaultSave3Image.rect.y && event.motion.y <= defaultSave3Image.rect.y + defaultSave3Image.rect.h) {
						hoverSave1 = false;
						hoverSave2 = false;
						hoverSave3 = true;
						hoverStart = false;
						hoverOverwrite = false;
						hoverBack = false;
					}
					else if (event.motion.x >= defaultStartImage.rect.x && event.motion.x <= defaultStartImage.rect.x + defaultStartImage.rect.w &&
					event.motion.y >= defaultStartImage.rect.y && event.motion.y <= defaultStartImage.rect.y + defaultStartImage.rect.h) {
						hoverSave1 = false;
						hoverSave2 = false;
						hoverSave3 = false;
						hoverStart = true;
						hoverOverwrite = false;
						hoverBack = false;
					}
					else if (event.motion.x >= defaultOverwriteImage.rect.x && event.motion.x <= defaultOverwriteImage.rect.x + defaultOverwriteImage.rect.w &&
					event.motion.y >= defaultOverwriteImage.rect.y && event.motion.y <= defaultOverwriteImage.rect.y + defaultOverwriteImage.rect.h) {
						hoverSave1 = false;
						hoverSave2 = false;
						hoverSave3 = false;
						hoverStart = false;
						hoverOverwrite = true;
						hoverBack = false;
					}
					else if (event.motion.x >= defaultBackImage.rect.x && event.motion.x <= defaultBackImage.rect.x + defaultBackImage.rect.w &&
					event.motion.y >= defaultBackImage.rect.y && event.motion.y <= defaultBackImage.rect.y + defaultBackImage.rect.h) {
						hoverSave1 = false;
						hoverSave2 = false;
						hoverSave3 = false;
						hoverStart = false;
						hoverOverwrite = false;
						hoverBack = true;
					}
					else {
						hoverSave1 = false;
						clickedSave1 = false;
						hoverSave2 = false;
						clickedSave2 = false;
						hoverSave3 = false;
						clickedSave3 = false;
						hoverStart = false;
						clickedStart = false;
						hoverOverwrite = false;
						clickedOverwrite = false;
						hoverBack = false;
						clickedBack = false;
					}
					break;
				case SDL_MOUSEBUTTONDOWN:
					if (event.button.button == SDL_BUTTON_LEFT && hoverSave1)
						clickedSave1 = true;
					else if (event.button.button == SDL_BUTTON_LEFT && hoverSave2)
						clickedSave2 = true;
					else if (event.button.button == SDL_BUTTON_LEFT && hoverSave3)
						clickedSave3 = true;
					else if (event.button.button == SDL_BUTTON_LEFT && hoverStart)
						clickedStart = true;
					else if (event.button.button == SDL_BUTTON_LEFT && hoverOverwrite)
						clickedOverwrite = true;
					else if (event.button.button == SDL_BUTTON_LEFT && hoverBack)
						clickedBack = true;
					break;
				case SDL_MOUSEBUTTONUP:
					if(hoverSave1){
						clickedSave1 = false;
						// INSERER ACTIONS DU CLIC ICI
					}
					else if(hoverSave2){
						clickedSave2 = false;
						// INSERER ACTIONS DU CLIC ICI
					}
					else if(hoverSave3){
						clickedSave3 = false;
						// INSERER ACTIONS DU CLIC ICI
					}
					else if(hoverStart){
						clickedStart = false;
						// INSERER ACTIONS DU CLIC ICI
					}
					else if(hoverOverwrite){
						clickedOverwrite = false;
						// INSERER ACTIONS DU CLIC ICI
					}
					else if(hoverBack){
						clickedBack = false;
						// INSERER ACTIONS DU CLIC ICI
						return 1;
					}
					break;
			}
		}

		// Effacement de l'cran
		SDL_RenderClear(renderer);

		// Affichage de l'image appropriée
		if (clickedSave1)
			SDL_RenderCopy(renderer, clickedSave1Image.texture, NULL, &clickedSave1Image.rect);
		else if (hoverSave1)
			SDL_RenderCopy(renderer, hoverSave1Image.texture, NULL, &hoverSave1Image.rect);
		else if (!clickedSave1 && !hoverSave1)
			SDL_RenderCopy(renderer, defaultSave1Image.texture, NULL, &defaultSave1Image.rect);
		if (clickedSave2)
			SDL_RenderCopy(renderer, clickedSave2Image.texture, NULL, &clickedSave2Image.rect);
		else if (hoverSave2)
			SDL_RenderCopy(renderer, hoverSave2Image.texture, NULL, &hoverSave2Image.rect);
		else if (!clickedSave2 && !hoverSave2)
			SDL_RenderCopy(renderer, defaultSave2Image.texture, NULL, &defaultSave2Image.rect);
		if (clickedSave3)
			SDL_RenderCopy(renderer, clickedSave3Image.texture, NULL, &clickedSave3Image.rect);
		else if (hoverSave3)
			SDL_RenderCopy(renderer, hoverSave3Image.texture, NULL, &hoverSave3Image.rect);
		else if (!clickedSave3 && !hoverSave3)
			SDL_RenderCopy(renderer, defaultSave3Image.texture, NULL, &defaultSave3Image.rect);
		if (clickedStart)
			SDL_RenderCopy(renderer, clickedStartImage.texture, NULL, &clickedStartImage.rect);
		else if (hoverStart)
			SDL_RenderCopy(renderer, hoverStartImage.texture, NULL, &hoverStartImage.rect);
		else if (!clickedStart && !hoverStart)
			SDL_RenderCopy(renderer, defaultStartImage.texture, NULL, &defaultStartImage.rect);
		if (clickedOverwrite)
			SDL_RenderCopy(renderer, clickedOverwriteImage.texture, NULL, &clickedOverwriteImage.rect);
		else if (hoverOverwrite)
			SDL_RenderCopy(renderer, hoverOverwriteImage.texture, NULL, &hoverOverwriteImage.rect);
		else if (!clickedOverwrite && !hoverOverwrite)
			SDL_RenderCopy(renderer, defaultOverwriteImage.texture, NULL, &defaultOverwriteImage.rect);
		if (clickedBack)
			SDL_RenderCopy(renderer, clickedBackImage.texture, NULL, &clickedBackImage.rect);
		else if (hoverBack)
			SDL_RenderCopy(renderer, hoverBackImage.texture, NULL, &hoverBackImage.rect);
		else if (!clickedBack && !hoverBack)
			SDL_RenderCopy(renderer, defaultBackImage.texture, NULL, &defaultBackImage.rect);

		// Affichage sur l'cran
		SDL_RenderPresent(renderer);
	}
	
	// Libration des ressources
	SDL_DestroyTexture(defaultSave1Image.texture);
	SDL_DestroyTexture(hoverSave1Image.texture);
	SDL_DestroyTexture(clickedSave1Image.texture);
	SDL_DestroyTexture(defaultSave2Image.texture);
	SDL_DestroyTexture(hoverSave2Image.texture);
	SDL_DestroyTexture(clickedSave2Image.texture);
	SDL_DestroyTexture(defaultSave3Image.texture);
	SDL_DestroyTexture(hoverSave3Image.texture);
	SDL_DestroyTexture(clickedSave3Image.texture);
	SDL_DestroyTexture(defaultStartImage.texture);
	SDL_DestroyTexture(hoverStartImage.texture);
	SDL_DestroyTexture(clickedStartImage.texture);
	SDL_DestroyTexture(defaultOverwriteImage.texture);
	SDL_DestroyTexture(hoverOverwriteImage.texture);
	SDL_DestroyTexture(clickedOverwriteImage.texture);
	SDL_DestroyTexture(defaultBackImage.texture);
	SDL_DestroyTexture(hoverBackImage.texture);
	SDL_DestroyTexture(clickedBackImage.texture);
	
	exit(1);
}
