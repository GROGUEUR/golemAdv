#ifndef EVENTOP_H
#define EVENTOP_H
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_mixer.h>
#include "type.h"
#include "texture.h"

/**
* déclaration des fonctions DetectEvents pour les sets d'évènement possible selon la scene
*/
void DetectEventsOp(int* , int* ,scene_t*);
void DetectEventsInvSac(int *useOk, int *yonUse,int *yonThrow,int *MouseClick,int *MouseOver, scene_t* scene,int w,int h,SDL_Rect destThrowButton);
void DetectEventsStats(int *numPage,int *MouseClick,int *MouseOver, scene_t* scene,int w,int h,SDL_Rect* destStatAction,team_t * team,float Stats[3][8]);

/**
* déclaration des fonctions ReactEvents pour les sets d'évènement possible selon la scene
*/
void ReactEventsOp(int,int*,SDL_Renderer* ,SDL_Texture* ,SDL_Texture* ,SDL_Texture* ,SDL_Rect*,SDL_Rect* ,int*,SDL_Rect*,SDL_Rect*,int,int);
void ReactEventsInvSac(int *useOk, int *yonUse,int *yonThrow,int MouseClick, int KeyIsPressed,int MouseOver,SDL_Renderer* pRenderer,SDL_Texture* Perso,SDL_Texture* pPnj,SDL_Texture* pBlock,SDL_Rect* marcheHori,SDL_Rect* dest,SDL_Rect* block,SDL_Rect* pnj,SDL_Texture* zone,int w,int h,inventaire_t*,SDL_Rect *destThrowButton, perso_t ** team);

void ReactEventsStats(int numPage,int MouseClick, int KeyIsPressed,int MouseOver,SDL_Renderer* pRenderer,SDL_Texture* Perso,SDL_Texture* pPnj,SDL_Texture* pBlock,SDL_Rect* marcheHori,SDL_Rect* dest,SDL_Rect* block,SDL_Rect* pnj,int w,int h,team_t * team,float Stats[3][8],SDL_Rect * destStatAction);
#endif

