#ifndef EVENTOP_H
#define EVENTOP_H
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_mixer.h>
#include "type.h"
#include "texture.h"

/**
* déclaration des fonctions DetectEvents et ReactEvents pour les sets d'évènement possible selon la scene
*/
void DetectEventsOp(int* , int* , int* ,scene_t*);
void DetectEventsP(int* , int* , int *, scene_t*);
void ReactEventsOp(int,int*,SDL_Renderer* ,SDL_Texture* ,SDL_Texture* ,SDL_Texture* ,SDL_Rect*,SDL_Rect* ,int*,SDL_Rect*,SDL_Rect*,int,int);
void ReactEventsP(SDL_Renderer* ,SDL_Texture*, SDL_Rect*);
void DetectEventsInvSac(int *useOk, int *yonUse,int *yonThrow,int *MouseClick,int *MouseOver, int* quit, scene_t* scene,int w,int h,SDL_Rect destThrowButton);
void ReactEventsInvSac(int *useOk, int *yonUse,int *yonThrow,int MouseClick, int KeyIsPressed,int MouseOver,SDL_Renderer* pRenderer,SDL_Texture* Perso,SDL_Texture* pPnj,SDL_Texture* pBlock,SDL_Rect* marcheHori,SDL_Rect* dest,SDL_Rect* block,SDL_Rect* pnj,SDL_Texture* zone,int w,int h,inventaire_t*,SDL_Rect *destThrowButton, perso_t ** team);
#endif

