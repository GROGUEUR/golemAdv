#include "../lib/type.h"
#include "../lib/texture.h"
#include <stdio.h>
#include <string.h>

int main(){
	perso_t * monPerso=malloc(sizeof(perso_t));
	printf("%d",creer_perso(monPerso,"Golemete","Golem"));
	printf("nom:%.0f\n",monPerso->For);
	free(monPerso);
	monPerso=NULL;
}
