#include <stdio.h>
#include "../lib/EventOp.h"
#include "../lib/texture.h"
#include "../lib/type.h"

int main(int argc, char** argv){
    /** initialisation de x pour les coordonnée src et i pour les boucles  
    * ainsi que de w et h pour récupérer la longueur et largeur de la fenètre
    */
    int i,x=0;
    int w=0,h=0;
    
    /** Initialisation de SDL pour les VIDEO, EVENTS et AUDIO */
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_EVENTS | SDL_INIT_AUDIO) != 0 ){
        fprintf(stdout,"Échec de l'initialisation de la SDL (%s)\n",SDL_GetError());
        return -1;
    }

    else{
    
        /** Création de la fenêtre */
        SDL_Window* pWindow = NULL;
        pWindow = SDL_CreateWindow("Ma première application SDL2",SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED,1390,728,SDL_WINDOW_SHOWN);
        SDL_GetWindowSize(pWindow,&w,&h);
        
        /** Initialisation de SDL_IMAGE */
        if (IMG_Init(IMG_INIT_PNG) != IMG_INIT_PNG) {
        	fprintf(stderr, "Erreur d'initialisation de SDL_image : %s\n", IMG_GetError());
        	SDL_Quit();
        	return 1;
    	}
    	
    	/** Initialisation de SDL_TTF */
    	if (TTF_Init() < 0) {
                fprintf(stderr, "Erreur d'initialisation de SDL_ttf : %s\n", TTF_GetError());
                IMG_Quit();
                SDL_Quit();
                return 1;
        }
        
        /** Initialisation de SDL_Mixer */
    	if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0) {
        	SDL_Log("Erreur lors de l'initialisation de SDL_mixer : %s", Mix_GetError());
        	IMG_Quit();
        	TTF_Quit();
        	SDL_Quit();
        	return 1;
        }
        
        if( pWindow )
        {
            /** Création d'un SDL_Renderer utilisant l'accélération matérielle */
            SDL_Renderer *pRenderer = SDL_CreateRenderer(pWindow,-1,SDL_RENDERER_ACCELERATED);
            if ( pRenderer )
            {
		    /** chargement des texture  du perso, etc ...*/
		    SDL_Texture* pPerso=loadTexture("../Ressource/scorpion.png",pRenderer);
		    SDL_Texture* pSol=loadTexture("../Ressource/navigateZone.png",pRenderer);
		    SDL_Texture* pBlock=loadTexture("../Ressource/blockZone.png",pRenderer);
		    SDL_Texture* pPnj=loadTexture("../Ressource/pnj.png",pRenderer);
                    if ( pPerso != NULL && pSol != NULL)
                    {
                        /** déclaration des destination du perso, map, block et pnj ainsi que des variable pour la music */
                        SDL_Rect dest = { w/2 - 64/2,h/2 - 64/2, 64,64};
                        SDL_Rect map = { 0,0, w,h};
                        SDL_Rect block = { w-280,h/2, 64,256};
                        SDL_Rect pnj = { w-280,(h/2)-64, 64,64};
                        Mix_Music * backOp = NULL;
                        Mix_Music * backP = NULL;
                        
                        /**
                        * création et initialisation d'un tableau selectionnant tout les sprites de l'animation de marche
                        */
                        SDL_Rect marcheHori[6];
                        for (i=0;i<6;i++){
                            marcheHori[i].x=x;
                            marcheHori[i].y=0;
                            marcheHori[i].w=32;
                            marcheHori[i].h=32;
                            x+=32;
                        }
             
                        /**
                        * declaration de quit etant la variable booleen qui met fin a la boucle
                        * declaration keyPressed pour gérer les touches
                        * declaration Action pour les interraction
                        * declaration MouseHover, Mouseclick pour gérer la sourti
                        */
                        int quit = 0, KeyIsPressed=0, Action=0,MouseOver=-1,MouseClick=-1,yonThrow=-1;
                        scene_t scene=OP;
                        objet_t allPot[9];
                        inventaire_t inventaire;
                        init_and_reinit_inv(&inventaire);
                        creer_all_objet(allPot,pRenderer);
                        ajouter_obj(&inventaire,allPot,0);
                        ajouter_obj(&inventaire,allPot,8);
                        SDL_Rect destThrowButton;
                        
                        /** boucle du jeux */
                        while (!quit) {
                        
                            /** récupération de la longueur et de la largeur de la fenètre */
                            SDL_GetWindowSize(pWindow,&w,&h);
                            
                            /** Regarde sur qu'elle scene nous sommes pour gérer les évènemnets et affichage */
                            switch(scene){
                            
                            	     /** Open World */
		                    case OP:
		                    	     if(backOp==NULL){
		                    	     	 Mix_FreeMusic(backP);
		                            	 backP=NULL;
		                    	     	 backOp = Mix_LoadMUS("../Ressource/OPZ.mp3");
		                		 Mix_PlayMusic(backOp, -1);
		                    	     }
				            /** détection des évènements */
				            DetectEventsOp(&KeyIsPressed,&quit,&Action,&scene);
				            /** réaction aux évènements */
				      
				            ReactEventsOp(KeyIsPressed,&Action,pRenderer,pPerso,pPnj,pBlock,marcheHori,&dest,&i,&block,&pnj,w,h);break;
				            
				    /** Menu Pause */
				    case PAUSE:
					       if(backP==NULL){
				                    	Mix_FreeMusic(backOp);
				                    	backOp=NULL;
				                    	backP = Mix_LoadMUS("../Ressource/Pause.mp3");
				        		Mix_PlayMusic(backP, -1);
				            	}
				            	DetectEventsP(&KeyIsPressed,&quit,&Action,&scene);
						    /** réaction aux évènements */
						    
					       ReactEventsP(pRenderer,allPot[1].sprite,&map);break;
					       
				   /** Menu Inventaire sac */
			           case INVENTORY:
			           	       if(KeyIsPressed>0){
			           	       	KeyIsPressed*=-1;
			           	       }
			           	       DetectEventsInvSac(&yonThrow,&MouseClick,&MouseOver,&quit,&scene,w,h,destThrowButton);
			         ReactEventsInvSac(&yonThrow,MouseClick,KeyIsPressed,MouseOver,pRenderer,pPerso,pPnj,pBlock,marcheHori,&dest,&block,&pnj,pPnj,w,h,&inventaire,&destThrowButton);break;
			    }
			    
			     /** Mise a jour de l'écran */
                            SDL_RenderPresent(pRenderer);
                        }
                        
                        /** réinitialisation de l'inventaire */
                        init_and_reinit_inv(&inventaire);
                        
                        /** Libération de la mémoire associée aux Musiques */
                        Mix_FreeMusic(backOp);
                        backOp=NULL;
                        Mix_FreeMusic(backP);
                        backP=NULL;
                        /** Libération de la mémoire associée aux texture */
                        SDL_DestroyTexture(pPerso); 
                        SDL_DestroyTexture(pSol);
                        SDL_DestroyTexture(pBlock);
                        SDL_DestroyTexture(pPnj);
                        for(i=0;i<9;i++){
			    	SDL_DestroyTexture(allPot[i].sprite);
			 }
                    }
                    else
                    {
                        fprintf(stdout,"Échec de création de la texture (%s)\n",SDL_GetError());
                    }
        
                SDL_DestroyRenderer(pRenderer); /** Libération de la mémoire du SDL_Renderer */
            }
            else
            {
                fprintf(stdout,"Échec de création du renderer (%s)\n",SDL_GetError());
            }
            SDL_Delay(1000); /** Attendre trois secondes, que l'utilisateur voie la fenêtre */
            SDL_DestroyWindow(pWindow);
        }
     else
        {
            fprintf(stderr,"Erreur de création de la fenêtre: %s\n",SDL_GetError());
        }
    }
    
    /** fermeture de toutes les extensions SDL, IMG, TTF et AUDIO */
    Mix_CloseAudio();
    TTF_Quit();
    IMG_Quit();
    SDL_Quit();
    return 0;
}

