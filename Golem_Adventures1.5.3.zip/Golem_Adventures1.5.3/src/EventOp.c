#include "../lib/EventOp.h"

/**
* fonction DetectEventsOp qui s'occupera de gérer la détection
* des évènement quand nous somme sur l'openWorld 
*/
void DetectEventsOp(int* KeyIsPressed, int* quit, int *Action, scene_t* scene){
    /** création de la variable event qui récupère les évènements */
    SDL_Event event;
    /** boucle d'attente d'évènements */
    while (SDL_PollEvent(&event) != 0) {
    	  /** regarde le bouton pour quitter la fenètre si appuyer met quit a 1 ce qui va arrêter la boucle de jeux */
          if (event.type == SDL_QUIT) {
             *quit = 1;
          }
          /** récuperation des touche enfoncer */
          if (event.type == SDL_KEYDOWN) {
          /** regarde qu'elle touche est enfoncer */
          	switch(event.key.keysym.sym){
          		case SDLK_q:
          		/** test si la touche est maintenu change la variable KeyIsPressed */
          			    if (*KeyIsPressed <= 0) {
                           		*KeyIsPressed = 1;
                       	    };break;
               	case SDLK_d:
		       	    if (*KeyIsPressed <= 0) {
		                       *KeyIsPressed = 2;
		                   };break;
               	case SDLK_z:
		       	    if (*KeyIsPressed <= 0) {
		                       *KeyIsPressed = 3;
		                   };break;
               	case SDLK_s:
		       	    if (*KeyIsPressed <= 0) {
		                       *KeyIsPressed = 4;
		                   };break;
		       case SDLK_f: *Action+=1 ;break;
		       case SDLK_ESCAPE: *scene=PAUSE ;break;
		       case SDLK_i: *scene=INVENTORY ;break;
		       case SDLK_e: *scene=EQUIPEMENT ;break;
		       case SDLK_t: *scene=STAT;break;
          	}
                 
          }                 
          /** récuperation des touche relacher changement de KeyIsPressed */
          else if (event.type == SDL_KEYUP) {
               /** regarde qu'elle touche a été relacher 
               * et change la variable KeyIsPressed en fonction de la touche 
               */
               switch(event.key.keysym.sym){
               	case SDLK_d:*KeyIsPressed = 0;break;
               	case SDLK_q:*KeyIsPressed = -1;break;
               	case SDLK_z:*KeyIsPressed = -2;break;
               	case SDLK_s:*KeyIsPressed = -3;break;

               }
         }
                                
    }
}

/**
* fonction ReactEventsOp qui s'occupe de réagire en fonction 
* des évènement quand nous somme sur l'openWorld
*/
void ReactEventsOp(int KeyIsPressed, int *Action,SDL_Renderer* pRenderer,SDL_Texture* Perso,SDL_Texture* pPnj,SDL_Texture* pBlock,SDL_Rect* marcheHori,SDL_Rect* dest,int* i,SDL_Rect* block,SDL_Rect* pnj,int w,int h){
     SDL_RenderClear(pRenderer);/** nettoyage de l'écran */
     SDL_RenderCopy(pRenderer,pPnj,NULL,pnj); /** placemet de la map */
     SDL_RenderCopy(pRenderer,pBlock,NULL,block);/** placement d'un block de collision */
     switch(KeyIsPressed){
        /** déplacement vers la gauche */
        case 1:
        	dest->x-=5;
		SDL_RenderCopyEx(pRenderer,Perso,marcheHori+((++*i)%6),dest, 0, NULL, SDL_FLIP_HORIZONTAL);break;
	/** déplacement vers la droite */
        case 2:
        	dest->x+=5;
        	SDL_RenderCopy(pRenderer,Perso,marcheHori+((++*i)%6),dest);break;
        /** déplacement vers le haut */
        case 3:
        	dest->y-=5;
        	SDL_RenderCopy(pRenderer,Perso,marcheHori+((++*i)%6),dest);break;
        /** déplacement vers le bas */
        case 4:
        	dest->y+=5;
        	SDL_RenderCopyEx(pRenderer,Perso,marcheHori+((++*i)%6),dest, 0, NULL, SDL_FLIP_HORIZONTAL);break;
        	
        case 0:SDL_RenderCopy(pRenderer,Perso,marcheHori+0,dest);break;
        
        case -1:SDL_RenderCopyEx(pRenderer,Perso,marcheHori+0,dest, 0, NULL, SDL_FLIP_HORIZONTAL);break;
        
        case -3:SDL_RenderCopy(pRenderer,Perso,marcheHori+0,dest);break;
        
        case -2:SDL_RenderCopyEx(pRenderer,Perso,marcheHori+0,dest, 0, NULL, SDL_FLIP_HORIZONTAL);break;
        
     }
     /** réinitialisation du i pour éviter qu'il dépasse la valeur max d'un int
     */
     if(*i%6==0){
     	*i=0;
     }
     
     /**
     * detection des hitbox d'un obstacle qui bloque le personnage
     */
     if ((dest->x>=block->x-64 && dest->x<=block->x+64)&&(dest->y>=block->y-124 && dest->y<=block->y+block->h-1)){
     	switch(KeyIsPressed){
     		case 1:dest->x=block->x+65;break;
     		case 2:dest->x=block->x-65;break;
     		case 3:dest->y=block->y+block->h;break;
     		case 4:dest->y=block->y-125;break;
   
     	}
     }
     /** 
     * test si le personnage est sur le point de sortir de l'écran
     * si oui le place du coté opposer de l'écran
     */
     if(dest->x<=-13 ||dest->x>=w-50 ||dest->y<=-13  ||dest->y>=h-50 ){
     	switch(KeyIsPressed){
     		case 1:dest->x=w-51;break;
     		case 2:dest->x=-12;break;
     		case 3:dest->y=h-51;break;
     		case 4:dest->y=-12;break;

     	}
     }
     
     /** test si le personnage est en face d'un pnj pour faire une interraction
     * une fois la touche f appuyer
     */
     if ((dest->x>=pnj->x-68 && dest->x<=pnj->x+68)&&(dest->y>=pnj->y-6 && dest->y<=pnj->y+24)){
     	if(*Action==1){
        	SDL_RenderCopy(pRenderer,pPnj,NULL,block); /** placemet de la map */
        }
     }
     else{
     	*Action=0;
     }
     /** delais d'affichage */
     SDL_Delay(35);
     
}


void DetectEventsP(int* KeyIsPressed, int* quit, int *Action, scene_t* scene){
    /** création de la variable event qui récupère les évènements */
    SDL_Event event;
    /** boucle d'attente d'évènements */
    while (SDL_PollEvent(&event) != 0) {
    	  /** regarde le bouton pour quitter la fenètre si appuyer met quit a 1 ce qui va arrêter la boucle de jeux */
          if (event.type == SDL_QUIT) {
             *quit = 1;
          }
          /** récuperation des touche enfoncer */
          if (event.type == SDL_KEYDOWN) {
          /** regarde qu'elle touche est enfoncer */
          	switch(event.key.keysym.sym){
		       case SDLK_ESCAPE: *scene=OP;break;
          	}
                 
          }                 
                                
    }
}

void ReactEventsP(SDL_Renderer* pRenderer,SDL_Texture* pSol, SDL_Rect* map){
     SDL_RenderClear(pRenderer);/** nettoyage de l'écran */
     SDL_RenderCopy(pRenderer,pSol,NULL,map); /** placemet de la map */
     SDL_Delay(35);
    
}

/**
* fonction DetectEventsInvSac qui s'occupera de gérer la détection
* des évènement quand nous somme sur le menu d'inventaire sur le sac 
*/
void DetectEventsInvSac(int *yonThrow,int* MouseClick,int *MouseOver, int* quit, scene_t* scene,int w,int h,SDL_Rect destThrowButton){

    /** création de la variable event qui récupère les évènements */
    SDL_Event event;
    
    /** coordonnés des zones ou ce situe les zones d'objets dans le menu */
    int Y=(h-h/2)+((h/2)/5)-2;
    int H=((h/2)-((h/2)/5)-2)/13;
    
    /** boucle d'attente d'évènements */
    while (SDL_PollEvent(&event) != 0) {
    
    	  /** regarde le bouton pour quitter la fenètre si appuyer met quit a 1 ce qui va arrêter la boucle de jeux */
    	  switch(event.type){
		  case SDL_QUIT:*quit = 1;break;
		  
		  /** récuperation des touche enfoncer */
		  case SDL_KEYDOWN:
		  /** regarde qu'elle touche est enfoncer */  
		  	switch(event.key.keysym.sym){
			       case SDLK_i: *scene=OP ;
			       	     *MouseClick=-1;break;
		  	};break;
		  	
		  /** récuperation des coordonnées de la sourits */
		  case SDL_MOUSEMOTION:
		  
		  /** regarde si la sourit est dans les case d'objets */
			  if (event.motion.x >= (w-w/2)+((w/2)/94)*3 && event.motion.x <= (w-w/2)+((w/2)/94)*3 + (w/4)){
			  	if(event.motion.y >= Y && event.motion.y <= Y+H){
			  		*MouseOver=0;
			  	}
			  	else if(event.motion.y >= Y+H+7 && event.motion.y <= Y+H+7+H){
			  		*MouseOver=1;
			  	}
			  	else if(event.motion.y >= Y+(H+7)*2 && event.motion.y <= Y+(H+7)*2+H){
			  		*MouseOver=2;
			  	}
			  	else if(event.motion.y >= Y+(H+7)*3 && event.motion.y <= Y+(H+7)*3+H){
			  		*MouseOver=3;
			  	}
			  	else if(event.motion.y >= Y+(H+7)*4 && event.motion.y <= Y+(H+7)*4+H){
			  		*MouseOver=4;
			  	}
			  	else if(event.motion.y >= Y+(H+7)*5 && event.motion.y <= Y+(H+7)*5+H){
			  		*MouseOver=5;
			  	}
			  	else if(event.motion.y >= Y+(H+7)*6 && event.motion.y <= Y+(H+7)*6+H){
			  		*MouseOver=6;
			  	}
			  	else if(event.motion.y >= Y+(H+7)*7 && event.motion.y <= Y+(H+7)*7+H){
			  		*MouseOver=7;
			  	}
			  	else if(event.motion.y >= Y+(H+7)*8 && event.motion.y <= Y+(H+7)*8+H){
			  		*MouseOver=8;
			  	}
			  	else if(event.motion.y >= Y+(H+7)*9 && event.motion.y <= Y+(H+7)*9+H){
			  		*MouseOver=9;
			  	}
			  	else{
			  		*MouseOver=-1;
			  	}
			  }
			  else{
			  	*MouseOver=-1;
			  }
			  
			  /** regarde si la sourit est sur le bouton jeter */
			  if(event.motion.x >= destThrowButton.x && event.motion.x <= destThrowButton.x+destThrowButton.w && event.motion.y >= destThrowButton.y && event.motion.y <= destThrowButton.y+destThrowButton.h){
			  	   	if(*MouseClick>=0 && *yonThrow==-1){
			  	   		*yonThrow=0;
			  	   	}
			  	   	
			  }
			  else if(*yonThrow==0){
			  	*yonThrow=-1;
			  }
			  /** regarde si la sourit est sur le bouton oui, non ou sur aucun des deux de la boite de texte pour jeter l'objet */
			  if(*yonThrow>=1 && *yonThrow<=3){
			  	if(event.motion.y >= ((h/6)*3)*1.05 && event.motion.y <= ((h/6)*5)/1.48){
			  		if(event.motion.x >= (((w/6)*3)/8)*7.15 && event.motion.x <= (((w/6)*3)/8)*7.65){
			  			*yonThrow=3;
			  		}
			  		else if(event.motion.x >= ((w/6)*3)+((((w/6)*3)/8)*7.65-(((w/6)*3)/8)*7.15)*0.65 && event.motion.x <= ((w/6)*3)+((((w/6)*3)/8)*7.65-(((w/6)*3)/8)*7.15)*1.65){
			  			*yonThrow=2;
			  		}
			  		else{
			  			*yonThrow=1;
			  		}
			  		
			  	}
			  	else{
			  		*yonThrow=1;
			  	}
			  } 
			  ;break;
			  
		   /** récuperation si le bouton de la sourit est lacher */
		   case SDL_MOUSEBUTTONUP:
		   
		   			   /** regarde si le bouton est relacher sur une zone d'objet de l'inventaire */
		   			   if(*MouseOver!=-1){
		   			   	*MouseClick=*MouseOver;
		   			   	if(*yonThrow=1){
		   			   		*yonThrow=-1;
		   			   	}
		   			   }
		   			   
		   			   /** regarde si le bouton est relacher sur le bouton jeter */
		   			   if(*yonThrow==0){
		   			   	*yonThrow=1;
		   			   }
		   			   
		   			   /** regarde si le bouton est relacher sur le bouton oui ou non de la boite de texte pour jeter l'objet */
		   			   else if(*yonThrow==2){
		   			   	*yonThrow=-1;
		   			   }
		   			   else if(*yonThrow==3){
		   			   	*yonThrow=5;
		   			   };break;
          }             
          
          
                                
    }
}

/**
* fonction ReactEventsInvSac qui s'occupe de réagire en fonction 
* des évènement quand nous somme sur le menu d'inventaire sur le sac 
*/
void ReactEventsInvSac(int *yonThrow,int MouseClick,int KeyIsPressed,int MouseOver,SDL_Renderer* pRenderer,SDL_Texture* Perso,SDL_Texture* pPnj,SDL_Texture* pBlock,SDL_Rect* marcheHori,SDL_Rect* dest,SDL_Rect* block,SDL_Rect* pnj,SDL_Texture* zone,int w,int h,inventaire_t* inv,SDL_Rect *destThrowButton){

     /** declaration de i servant au boucle for et textwidth, textheight pour les dimensions des textes */
     int i, textwidth, textheight;
     
     /** chargement des textures nécessaires aux menu */
     SDL_Texture* objClick=loadTexture("../Ressource/objSelect.png",pRenderer);
     SDL_Texture* objOver=loadTexture("../Ressource/objOver.png",pRenderer);
     SDL_Texture* menu=loadTexture("../Ressource/MenuInvSac.png",pRenderer);
     SDL_Texture* buttonThrow=loadTexture("../Ressource/throwButton.png",pRenderer);
     SDL_Texture* buttonThrowOver=loadTexture("../Ressource/throwButtonOver.png",pRenderer);
     SDL_Texture* boxYoNThrow=loadTexture("../Ressource/yOnThrow.png",pRenderer);
     
     
     /** declaration des rect correspondant au coordonnées et dimensions d'affichage du menu */
     int temp=w/5+((w/2)/94)*2.8;
     SDL_Rect destMenu={w-w/2,h-h/2,w/2,h/2};
     SDL_Rect destzone={(w-w/2)+((w/2)/94)*3,(h-h/2)+((h/2)/5)-2,(w/4),((h/2)-((h/2)/5)-2)/13};
     SDL_Rect destImage={destzone.x+destzone.w+((w/2)/94)*3+temp/5,(h-h/2)+((h/2)/5)-2,h/4,h/4};
     
     
     SDL_Rect destBoxYoNThrow={w/2-w/6/2,h/2-h/6/2,w/6,h/6};
     
     /** declaration et initialisation des textures des noms et descriptions des objets ainsi que la couleur du texte */
     SDL_Texture* nomObj[10];
     SDL_Texture* descObj[10];
     SDL_Color color={255,255,255};
     for(i=0;i<10;i++){
     	if(inv->sac[i]!=NULL){
     		nomObj[i]=loadTextureFont("../Ressource/font/BlockKie.ttf",pRenderer,inv->sac[i]->nom,destzone.h,color);
     		descObj[i]=loadTextureFont("../Ressource/font/BlockKie.ttf",pRenderer,inv->sac[i]->desc,destzone.h,color);
     	}
     	else{
     		nomObj[i]=loadTextureFont("../Ressource/font/BlockKie.ttf",pRenderer,". . .",destzone.h,color);
     		descObj[i]=loadTextureFont("../Ressource/font/BlockKie.ttf",pRenderer,"aucun objet",destzone.h,color);
     	}
     }
     
     /** declaration de la variable pour les coordonnées et dimensions des noms d'objets */
     SDL_Rect destNom;
     
     /** coordonnées et dimensions de la ddescription des objets */
     SDL_Rect destDesc={destImage.x-destImage.w/4-destImage.w/35,destImage.y+destImage.h+5,w/5+destImage.w/35,destzone.h+10};
     SDL_Rect destNoDesc={destImage.x,destImage.y+destImage.h/2,destImage.w-5,destzone.h+10};
     
     destThrowButton->x=destDesc.x+(destDesc.w/3)*2;
     destThrowButton->y=destDesc.y+destDesc.h*1.5;
     destThrowButton->w=destDesc.w/3;
     destThrowButton->h=destDesc.h;
     
     /** nettoyage de l'écran puis affichage de l'écran actuel ou l'on est dans l'open world*/
     SDL_RenderClear(pRenderer);/** nettoyage de l'écran */
     SDL_RenderCopy(pRenderer,pPnj,NULL,pnj); /** placemet de la map */
     SDL_RenderCopy(pRenderer,pBlock,NULL,block);/** placement d'un block de collision */
     switch(KeyIsPressed){
        case 0:SDL_RenderCopy(pRenderer,Perso,marcheHori+0,dest);break;
        
        case -1:SDL_RenderCopyEx(pRenderer,Perso,marcheHori+0,dest, 0, NULL, SDL_FLIP_HORIZONTAL);break;
        
        case -3:SDL_RenderCopy(pRenderer,Perso,marcheHori+0,dest);break;
        
        case -2:SDL_RenderCopyEx(pRenderer,Perso,marcheHori+0,dest, 0, NULL, SDL_FLIP_HORIZONTAL);break;
     }
     
     /** affichage du menu */
     SDL_RenderCopy(pRenderer,menu,NULL,&destMenu);
     
     /** affichage des objets présent ou non ainsi que la zone sur laquelle la sourit a cliquer ou est positionner */
     for(i=0;i<10;i++){
     	if(MouseClick==i){
     		SDL_RenderCopy(pRenderer,objClick,NULL,&destzone);
     	}
     	else if(MouseOver==i){
     		SDL_RenderCopy(pRenderer,objOver,NULL,&destzone);
     	}
     	/** mise a jour des coordonnées et dimensions des noms d'objets */
     	SDL_QueryTexture(nomObj[i], NULL, NULL, &textwidth, &textheight);
     	destNom.x=destzone.x+(destzone.w/2-textwidth/2);
     	destNom.y=destzone.y+((destzone.h/2-textheight/2));
     	destNom.w=textwidth;
     	destNom.h=textheight;
     	
     	
     	/** affichage des noms d'objets si il n'y a pas d'objet affiche ". . ." */
     	SDL_RenderCopy(pRenderer,nomObj[i],NULL,&destNom);
     	destzone.y+=destzone.h+7;
     }
     
     /** test si il y a un objet a cet emplacement du sac,
     *   si oui affiche l'image, la description et les boutons jeter et utiliser,
     *   sinon affiche le texte "rien"
     */
     if(MouseClick!=-1){
     	if(inv->sac[MouseClick]!=NULL){
     		SDL_RenderCopy(pRenderer,inv->sac[MouseClick]->sprite,NULL,&destImage);
     		SDL_RenderCopy(pRenderer,descObj[MouseClick],NULL,&destDesc);
     		if(*yonThrow==0){
     			SDL_RenderCopy(pRenderer,buttonThrowOver,NULL,destThrowButton);
     		}
     		else if(*yonThrow>=1 && *yonThrow <=3){
     			SDL_RenderCopy(pRenderer,buttonThrow,NULL,destThrowButton);
     			SDL_RenderCopy(pRenderer,boxYoNThrow,NULL,&destBoxYoNThrow);
     		}
     		else if(*yonThrow==5){
     			jeter_obj(inv,MouseClick);
     			*yonThrow=-1;
     		}
     		
     		else{
     			SDL_RenderCopy(pRenderer,buttonThrow,NULL,destThrowButton);
     		}
     		
     	}
     	else{
     		SDL_RenderCopy(pRenderer,descObj[MouseClick],NULL,&destNoDesc);
     	}
     	
     }
     
     /** destruction des textures utiliser pour le menu */
     SDL_DestroyTexture(objOver); 
     SDL_DestroyTexture(objClick);
     SDL_DestroyTexture(menu);
     SDL_DestroyTexture(buttonThrow);
     SDL_DestroyTexture(buttonThrowOver);
     SDL_DestroyTexture(boxYoNThrow);
     
     /** destruction des textures des noms et descriptions des objets */
     for(i=0;i<10;i++){
     	SDL_DestroyTexture(nomObj[i]);
     	SDL_DestroyTexture(descObj[i]);
     }
     
     /** delais d'affichage */
     SDL_Delay(35);
     
}
