#include "../lib/EventOp.h"

/**
* fonction DetectEventsOp qui s'occupera de gérer la détection
* des évènement quand nous somme sur l'openWorld 
*/
void DetectEventsOp(int* KeyIsPressed, int* quit, int *Action, scene_t* scene){
    /** création de la variable event qui récupère les évènements */
    SDL_Event event;
    /** boucle d'attente d'évènements */
    while (SDL_PollEvent(&event) != 0) {
    	  /** regarde le bouton pour quitter la fenètre si appuyer met quit a 1 ce qui va arrêter la boucle de jeux */
          if (event.type == SDL_QUIT) {
             *quit = 1;
          }
          /** récuperation des touche enfoncer */
          if (event.type == SDL_KEYDOWN) {
          /** regarde qu'elle touche est enfoncer */
          	switch(event.key.keysym.sym){
          		case SDLK_q:
          		/** test si la touche est maintenu change la variable KeyIsPressed */
          			    if (*KeyIsPressed <= 0) {
                           		*KeyIsPressed = 1;
                       	    };break;
               	case SDLK_d:
		       	    if (*KeyIsPressed <= 0) {
		                       *KeyIsPressed = 2;
		                   };break;
               	case SDLK_z:
		       	    if (*KeyIsPressed <= 0) {
		                       *KeyIsPressed = 3;
		                   };break;
               	case SDLK_s:
		       	    if (*KeyIsPressed <= 0) {
		                       *KeyIsPressed = 4;
		                   };break;
		       case SDLK_f: *Action+=1 ;break;
		       case SDLK_ESCAPE: *scene=PAUSE ;break;
		       case SDLK_i: *scene=INVENTORY ;break;
		       case SDLK_e: *scene=EQUIPEMENT ;break;
		       case SDLK_t: *scene=STAT;break;
          	}
                 
          }                 
          /** récuperation des touche relacher changement de KeyIsPressed */
          else if (event.type == SDL_KEYUP) {
               /** regarde qu'elle touche a été relacher 
               * et change la variable KeyIsPressed en fonction de la touche 
               */
               switch(event.key.keysym.sym){
               	case SDLK_d:*KeyIsPressed = 0;break;
               	case SDLK_q:*KeyIsPressed = -1;break;
               	case SDLK_z:*KeyIsPressed = -2;break;
               	case SDLK_s:*KeyIsPressed = -3;break;

               }
         }
                                
    }
}

/**
* fonction ReactEventsOp qui s'occupe de réagire en fonction 
* des évènement quand nous somme sur l'openWorld
*/
void ReactEventsOp(int KeyIsPressed, int *Action,SDL_Renderer* pRenderer,SDL_Texture* Perso,SDL_Texture* pPnj,SDL_Texture* pBlock,SDL_Rect* marcheHori,SDL_Rect* dest,int* i,SDL_Rect* block,SDL_Rect* pnj,int w,int h){
     SDL_RenderClear(pRenderer);/** nettoyage de l'écran */
     SDL_RenderCopy(pRenderer,pPnj,NULL,pnj); /** placemet de la map */
     SDL_RenderCopy(pRenderer,pBlock,NULL,block);/** placement d'un block de collision */
     switch(KeyIsPressed){
        /** déplacement vers la gauche */
        case 1:
        	dest->x-=5;
		SDL_RenderCopyEx(pRenderer,Perso,marcheHori+((++*i)%6),dest, 0, NULL, SDL_FLIP_HORIZONTAL);break;
	/** déplacement vers la droite */
        case 2:
        	dest->x+=5;
        	SDL_RenderCopy(pRenderer,Perso,marcheHori+((++*i)%6),dest);break;
        /** déplacement vers le haut */
        case 3:
        	dest->y-=5;
        	SDL_RenderCopy(pRenderer,Perso,marcheHori+((++*i)%6),dest);break;
        /** déplacement vers le bas */
        case 4:
        	dest->y+=5;
        	SDL_RenderCopyEx(pRenderer,Perso,marcheHori+((++*i)%6),dest, 0, NULL, SDL_FLIP_HORIZONTAL);break;
        	
        case 0:SDL_RenderCopy(pRenderer,Perso,marcheHori+0,dest);break;
        
        case -1:SDL_RenderCopyEx(pRenderer,Perso,marcheHori+0,dest, 0, NULL, SDL_FLIP_HORIZONTAL);break;
        
        case -3:SDL_RenderCopy(pRenderer,Perso,marcheHori+0,dest);break;
        
        case -2:SDL_RenderCopyEx(pRenderer,Perso,marcheHori+0,dest, 0, NULL, SDL_FLIP_HORIZONTAL);break;
        
     }
     /** réinitialisation du i pour éviter qu'il dépasse la valeur max d'un int
     */
     if(*i%6==0){
     	*i=0;
     }
     
     /**
     * detection des hitbox d'un obstacle qui bloque le personnage
     */
     if ((dest->x>=block->x-64 && dest->x<=block->x+64)&&(dest->y>=block->y-124 && dest->y<=block->y+block->h-1)){
     	switch(KeyIsPressed){
     		case 1:dest->x=block->x+65;break;
     		case 2:dest->x=block->x-65;break;
     		case 3:dest->y=block->y+block->h;break;
     		case 4:dest->y=block->y-125;break;
   
     	}
     }
     /** 
     * test si le personnage est sur le point de sortir de l'écran
     * si oui le place du coté opposer de l'écran
     */
     if(dest->x<=-13 ||dest->x>=w-50 ||dest->y<=-13  ||dest->y>=h-50 ){
     	switch(KeyIsPressed){
     		case 1:dest->x=w-51;break;
     		case 2:dest->x=-12;break;
     		case 3:dest->y=h-51;break;
     		case 4:dest->y=-12;break;

     	}
     }
     
     /** test si le personnage est en face d'un pnj pour faire une interraction
     * une fois la touche f appuyer
     */
     if ((dest->x>=pnj->x-68 && dest->x<=pnj->x+68)&&(dest->y>=pnj->y-6 && dest->y<=pnj->y+24)){
     	if(*Action==1){
        	SDL_RenderCopy(pRenderer,pPnj,NULL,block); /** placemet de la map */
        }
     }
     else{
     	*Action=0;
     }
     /** delais d'affichage */
     SDL_Delay(35);
     
}


void DetectEventsP(int* KeyIsPressed, int* quit, int *Action, scene_t* scene){
    /** création de la variable event qui récupère les évènements */
    SDL_Event event;
    /** boucle d'attente d'évènements */
    while (SDL_PollEvent(&event) != 0) {
    	  /** regarde le bouton pour quitter la fenètre si appuyer met quit a 1 ce qui va arrêter la boucle de jeux */
          if (event.type == SDL_QUIT) {
             *quit = 1;
          }
          /** récuperation des touche enfoncer */
          if (event.type == SDL_KEYDOWN) {
          /** regarde qu'elle touche est enfoncer */
          	switch(event.key.keysym.sym){
		       case SDLK_ESCAPE: *scene=OP;break;
          	}
                 
          }                 
                                
    }
}

void ReactEventsP(SDL_Renderer* pRenderer,SDL_Texture* pSol, SDL_Rect* map){
     SDL_RenderClear(pRenderer);/** nettoyage de l'écran */
     SDL_RenderCopy(pRenderer,pSol,NULL,map); /** placemet de la map */
     SDL_Delay(35);
    
}

/**
* fonction DetectEventsInvSac qui s'occupera de gérer la détection
* des évènement quand nous somme sur le menu d'inventaire sur le sac 
*/
void DetectEventsInvSac(int *useOk, int *yonUse,int *yonThrow,int* MouseClick,int *MouseOver, int* quit, scene_t* scene,int w,int h,SDL_Rect destThrowButton){

    /** création de la variable event qui récupère les évènements */
    SDL_Event event;
    
    /** coordonnés des zones ou ce situe les zones d'objets dans le menu */
    int Y=(h-h/2)+((h/2)/5)-2;
    int H=((h/2)-((h/2)/5)-2)/13;
    
    /** boucle d'attente d'évènements */
    while (SDL_PollEvent(&event) != 0) {
    
    	  /** regarde le bouton pour quitter la fenètre si appuyer met quit a 1 ce qui va arrêter la boucle de jeux */
    	  switch(event.type){
		  case SDL_QUIT:*quit = 1;break;
		  
		  /** récuperation des touche enfoncer */
		  case SDL_KEYDOWN:
		  /** regarde qu'elle touche est enfoncer */  
		  	switch(event.key.keysym.sym){
			       case SDLK_i: *scene=OP ;
			       	     *MouseClick=-1;break;
			       case SDLK_ESCAPE:
		       		if(*yonUse>=1){
		       			*yonUse=-1;
		       		};break;
			       case SDLK_TAB:
			       	*scene=STAT ;
			       	*MouseClick=-1;break;
		  	};break;
		  	
		  /** récuperation des coordonnées de la sourits */
		  case SDL_MOUSEMOTION:
		  
		  /** regarde si la sourit est dans les case d'objets */
			  if (event.motion.x >= (w-w/2)+((w/2)/94)*3 && event.motion.x <= (w-w/2)+((w/2)/94)*3 + (w/4)){
			  	if(event.motion.y >= Y && event.motion.y <= Y+H){
			  		*MouseOver=0;
			  	}
			  	else if(event.motion.y >= Y+H+7 && event.motion.y <= Y+H+7+H){
			  		*MouseOver=1;
			  	}
			  	else if(event.motion.y >= Y+(H+7)*2 && event.motion.y <= Y+(H+7)*2+H){
			  		*MouseOver=2;
			  	}
			  	else if(event.motion.y >= Y+(H+7)*3 && event.motion.y <= Y+(H+7)*3+H){
			  		*MouseOver=3;
			  	}
			  	else if(event.motion.y >= Y+(H+7)*4 && event.motion.y <= Y+(H+7)*4+H){
			  		*MouseOver=4;
			  	}
			  	else if(event.motion.y >= Y+(H+7)*5 && event.motion.y <= Y+(H+7)*5+H){
			  		*MouseOver=5;
			  	}
			  	else if(event.motion.y >= Y+(H+7)*6 && event.motion.y <= Y+(H+7)*6+H){
			  		*MouseOver=6;
			  	}
			  	else if(event.motion.y >= Y+(H+7)*7 && event.motion.y <= Y+(H+7)*7+H){
			  		*MouseOver=7;
			  	}
			  	else if(event.motion.y >= Y+(H+7)*8 && event.motion.y <= Y+(H+7)*8+H){
			  		*MouseOver=8;
			  	}
			  	else if(event.motion.y >= Y+(H+7)*9 && event.motion.y <= Y+(H+7)*9+H){
			  		*MouseOver=9;
			  	}
			  	else{
			  		*MouseOver=-1;
			  	}
			  }
			  else{
			  	*MouseOver=-1;
			  }
			  
			  /** regarde si la sourit est sur le bouton jeter */
			  if(event.motion.x >= destThrowButton.x && event.motion.x <= destThrowButton.x+destThrowButton.w && event.motion.y >= destThrowButton.y && event.motion.y <= destThrowButton.y+destThrowButton.h){
			  	   	if(*MouseClick>=0 && *yonThrow==-1){
			  	   		*yonThrow=0;
			  	   	}
			  	   	
			  }
			  else if(*yonThrow==0){
			  	*yonThrow=-1;
			  }
			  
			  /** regarde si la sourit est sur le bouton utiliser */
			  if(event.motion.x >= destThrowButton.x/1.11 && event.motion.x <= destThrowButton.x/1.11+destThrowButton.w && event.motion.y >= destThrowButton.y && event.motion.y <= destThrowButton.y+destThrowButton.h){
			  	   	if(*MouseClick>=0 && *yonUse==-1){
			  	   		*yonUse=0;
			  	   	}
			  }
			  else if(*yonUse==0){
			  	*yonUse=-1;
			  }
			  
			  /** regarde si la sourit est sur le bouton oui, non ou sur aucun des deux de la boite de texte pour jeter l'objet */
			  if(*yonThrow>=1 && *yonThrow<=3){
			  	if(event.motion.y >= ((h/6)*3)*1.05 && event.motion.y <= ((h/6)*5)/1.48){
			  		if(event.motion.x >= (((w/6)*3)/8)*7.15 && event.motion.x <= (((w/6)*3)/8)*7.65){
			  			*yonThrow=3;
			  		}
			  		else if(event.motion.x >= ((w/6)*3)+((((w/6)*3)/8)*7.65-(((w/6)*3)/8)*7.15)*0.65 && event.motion.x <= ((w/6)*3)+((((w/6)*3)/8)*7.65-(((w/6)*3)/8)*7.15)*1.65){
			  			*yonThrow=2;
			  		}
			  		else{
			  			*yonThrow=1;
			  		}
			  		
			  	}
			  	else{
			  		*yonThrow=1;
			  	}
			  }
			  
			  /** regarde si la sourit est sur un personnage pouvant utiliser un objet */
			  if(*yonUse>=1 && *yonUse<=4){
			  	if(event.motion.x >= (w/2-w/6/2)+(w/2-w/6/2)/45 && event.motion.x <= (w/2-w/6/2)+(w/2-w/6/2)/45+(w/4.8)){
			  		if((event.motion.y >= (h/2-h/6/2)+2 && event.motion.y <= (h/2-h/6/2)+2+((h/6)/3.5)/1.5) && useOk[0]==0){
			  			*yonUse=2;
			  		}
			  		else if((event.motion.y >= (h/2-h/6/2)+2+(((h/6)/3.5)/1.5)*2 && event.motion.y <= (h/2-h/6/2)+2+(((h/6)/3.5)/1.5)*3) && useOk[1]==0){
			  			*yonUse=3;
			  		}
			  		else if((event.motion.y >= (h/2-h/6/2)+2+(((h/6)/3.5)/1.5)*5 && event.motion.y <= (h/2-h/6/2)+2+(((h/6)/3.5)/1.5)*6) && useOk[2]==0){
			  			*yonUse=4;
			  		}
			  		else{
			  			*yonUse=1;
			  		}
			  		
			  	}
			  	else{
			  		*yonUse=1;
			  	}
			  };break;
			  
		   /** récuperation si le bouton de la sourit est lacher */
		   case SDL_MOUSEBUTTONUP:
		   
   			   /** regarde si le bouton est relacher sur une zone d'objet de l'inventaire */
   			   if(*MouseOver!=-1){
   			   	*MouseClick=*MouseOver;
   			   	if(*yonThrow=1){
   			   		*yonThrow=-1;
   			   	}
   			   	if(*yonUse=1){
   			   		*yonUse=-1;
   			   	}
   			   }
   			   
   			   /** regarde si le bouton est relacher sur le bouton jeter */
   			   if(*yonThrow==0){
   			   	*yonThrow=1;
   			   }
   			   
   			   /** regarde si le bouton est relacher sur le bouton oui ou non de la boite de texte pour jeter l'objet */
   			   else if(*yonThrow==2){
   			   	*yonThrow=-1;
   			   }
   			   else if(*yonThrow==3){
   			   	*yonThrow=5;
   			   }
   			   
   			   /** regarde si le bouton est relacher sur le bouton utiliser */
   			   if(*yonUse==0){
   			   	*yonUse=1;
   			   }
   			   else if(*yonUse==2){
   			   	*yonUse=5;
   			   }
   			   else if(*yonUse==3){
   			   	*yonUse=6;
   			   }
   			   else if(*yonUse==4){
   			   	*yonUse=7;
   			   };break;
          }              
    }
}

/**
* fonction ReactEventsInvSac qui s'occupe de réagire en fonction 
* des évènement quand nous somme sur le menu d'inventaire sur le sac 
*/
void ReactEventsInvSac(int *useOk, int *yonUse,int *yonThrow,int MouseClick,int KeyIsPressed,int MouseOver,SDL_Renderer* pRenderer,SDL_Texture* Perso,SDL_Texture* pPnj,SDL_Texture* pBlock,SDL_Rect* marcheHori,SDL_Rect* dest,SDL_Rect* block,SDL_Rect* pnj,SDL_Texture* zone,int w,int h,inventaire_t* inv,SDL_Rect *destThrowButton,perso_t ** team){

     /** declaration de i servant au boucle for et textwidth, textheight pour les dimensions des textes */
     int i, textwidth, textheight;
     
     /** chaine de caractère utiliser pour l'affichage des persos avec leur nb de pv et pm  */
     char pv[4];
     char pvm[4];
     char pm[4];
     char pmm[4];
     char personnage[40];
     
     
     /** chargement des textures nécessaires aux menu */
     SDL_Texture* objClick=loadTexture("../Ressource/objSelect.png",pRenderer);
     SDL_Texture* objOver=loadTexture("../Ressource/objOver.png",pRenderer);
     SDL_Texture* menu=loadTexture("../Ressource/MenuInvSac.png",pRenderer);
     
     /** chargement des textures nécessaires au bouton jeter et ça boite */
     SDL_Texture* buttonThrow=loadTexture("../Ressource/throwButton.png",pRenderer);
     SDL_Texture* buttonThrowOver=loadTexture("../Ressource/throwButtonOver.png",pRenderer);
     SDL_Texture* boxYoNThrow=loadTexture("../Ressource/yOnThrow.png",pRenderer);
     
     /** chargement des textures nécessaires au bouton utiliser et ça boite */
     SDL_Texture* buttonUse=loadTexture("../Ressource/useButton.png",pRenderer);
     SDL_Texture* buttonUseOver=loadTexture("../Ressource/useButtonOver.png",pRenderer);
     SDL_Texture* boxYoNUse=loadTexture("../Ressource/yonUse.png",pRenderer);
     
     
     /** declaration des rect correspondant au coordonnées et dimensions d'affichage du menu */
     int temp=w/5+((w/2)/94)*2.8;
     SDL_Rect destMenu={w-w/2,h-h/2,w/2,h/2};
     SDL_Rect destzone={(w-w/2)+((w/2)/94)*3,(h-h/2)+((h/2)/5)-2,(w/4),((h/2)-((h/2)/5)-2)/13};
     SDL_Rect destImage={destzone.x+destzone.w+((w/2)/94)*3+temp/5,(h-h/2)+((h/2)/5)-2,h/4,h/4};
     
     /** declaration des rect correspondant au coordonnées et dimensions d'affichage des boites utiliser et jeter
     *  ainsi que des personnage pour la boite d'utilisation 
     */
     SDL_Rect destBoxYoNThrow={w/2-w/6/2,h/2-h/6/2,w/6,h/6};
     SDL_Rect destBoxYoNUse={w/2-w/6/2,h/2-h/6/2,w/4.7,h/6};
     SDL_Rect destYoNPerso={destBoxYoNUse.x+destBoxYoNUse.x/45,(h/2-h/6/2)+2,0,(destBoxYoNUse.h/3.5)/1.5};
     
     
     /** declaration et initialisation des textures des noms et descriptions des objets ainsi que la couleur des texte */
     SDL_Texture* nomObj[10];
     SDL_Texture* descObj[10];
     SDL_Color blanc={255,255,255};
     SDL_Color gris={195,195,195};
     for(i=0;i<10;i++){
     	if(inv->sac[i]!=NULL){
     		nomObj[i]=loadTextureFont("../Ressource/font/BlockKie.ttf",pRenderer,inv->sac[i]->nom,destzone.h,blanc);
     		descObj[i]=loadTextureFont("../Ressource/font/BlockKie.ttf",pRenderer,inv->sac[i]->desc,destzone.h,blanc);
     	}
     	else{
     		nomObj[i]=loadTextureFont("../Ressource/font/BlockKie.ttf",pRenderer,". . .",destzone.h,blanc);
     		descObj[i]=loadTextureFont("../Ressource/font/BlockKie.ttf",pRenderer,"aucun objet",destzone.h,blanc);
     	}
     }
     
     /** déclaration et initialisation des texture des textes des personnages dans la boite d'utilisation d'objet*/
     SDL_Texture* perso[3];
     SDL_Texture* persoBlocked[3];
     for(i=0;i<3;i++){
     	if(team[i]!=NULL){
     		strcpy(personnage,team[i]->Nom);
     		sprintf(pv,"%.0f",team[i]->Pv);
     		sprintf(pvm,"%.0f",team[i]->PvMax);
     		sprintf(pm,"%.0f",team[i]->Mana);
     		sprintf(pmm,"%.0f",team[i]->ManaMax);
     		strcat(personnage," PV: ");
     		strcat(personnage,pv);
     		strcat(personnage,"/");
     		strcat(personnage,pvm);
     		strcat(personnage," PM: ");
     		strcat(personnage,pm);
     		strcat(personnage,"/");
     		strcat(personnage,pmm);
     		perso[i]=loadTextureFont("../Ressource/font/BlockKie.ttf",pRenderer,personnage,(destBoxYoNUse.h/3.5)/1.5,blanc);
     		persoBlocked[i]=loadTextureFont("../Ressource/font/BlockKie.ttf",pRenderer,personnage,(destBoxYoNUse.h/3.5)/1.5,gris);
     	}
     	else{
     		perso[i]=loadTextureFont("../Ressource/font/BlockKie.ttf",pRenderer,". . .",(destBoxYoNUse.h/3.5)/1.5,gris);
     		persoBlocked[i]=loadTextureFont("../Ressource/font/BlockKie.ttf",pRenderer,". . .",(destBoxYoNUse.h/3.5)/1.5,gris);
     	}
     }
     
     /** declaration de la variable pour les coordonnées et dimensions des noms d'objets */
     SDL_Rect destNom;
     
     /** coordonnées et dimensions de la description des objets */
     SDL_Rect destDesc={destImage.x-destImage.w/4-destImage.w/35,destImage.y+destImage.h+5,w/5+destImage.w/35,destzone.h+10};
     SDL_Rect destNoDesc={destImage.x,destImage.y+destImage.h/2,destImage.w-5,destzone.h+10};
     
     /** coordonnée et destination du bouton jeter */
     destThrowButton->x=destDesc.x+(destDesc.w/3)*1.7;
     destThrowButton->y=destDesc.y+destDesc.h*1.5;
     destThrowButton->w=destDesc.w/3;
     destThrowButton->h=destDesc.h;
     
     /** coordonnée et destination du bouton utiliser */
     SDL_Rect destUseButton={destThrowButton->x/1.11,destThrowButton->y,destThrowButton->w,destThrowButton->h};
     
     /** nettoyage de l'écran puis affichage de l'écran actuel ou l'on est dans l'open world*/
     SDL_RenderClear(pRenderer);/** nettoyage de l'écran */
     SDL_RenderCopy(pRenderer,pPnj,NULL,pnj); /** placemet de la map */
     SDL_RenderCopy(pRenderer,pBlock,NULL,block);/** placement d'un block de collision */
     switch(KeyIsPressed){
        case 0:SDL_RenderCopy(pRenderer,Perso,marcheHori+0,dest);break;
        
        case -1:SDL_RenderCopyEx(pRenderer,Perso,marcheHori+0,dest, 0, NULL, SDL_FLIP_HORIZONTAL);break;
        
        case -3:SDL_RenderCopy(pRenderer,Perso,marcheHori+0,dest);break;
        
        case -2:SDL_RenderCopyEx(pRenderer,Perso,marcheHori+0,dest, 0, NULL, SDL_FLIP_HORIZONTAL);break;
     }
     
     /** affichage du menu */
     SDL_RenderCopy(pRenderer,menu,NULL,&destMenu);
     
     /** affichage des objets présent ou non ainsi que la zone sur laquelle la sourit a cliquer ou est positionner */
     for(i=0;i<10;i++){
     	if(MouseClick==i){
     		SDL_RenderCopy(pRenderer,objClick,NULL,&destzone);
     	}
     	else if(MouseOver==i){
     		SDL_RenderCopy(pRenderer,objOver,NULL,&destzone);
     	}
     	
     	/** mise a jour des coordonnées et dimensions des noms d'objets */
     	SDL_QueryTexture(nomObj[i], NULL, NULL, &textwidth, &textheight);
     	destNom.x=destzone.x+(destzone.w/2-textwidth/2);
     	destNom.y=destzone.y+((destzone.h/2-textheight/2));
     	destNom.w=textwidth;
     	destNom.h=textheight;
     	
     	
     	/** affichage des noms d'objets si il n'y a pas d'objet affiche ". . ." */
     	SDL_RenderCopy(pRenderer,nomObj[i],NULL,&destNom);
     	destzone.y+=destzone.h+7;
     }
     
     /** test si il y a un objet a cet emplacement du sac,
     *   si oui affiche l'image, la description et les boutons jeter et utiliser,
     *   sinon affiche le texte "rien"
     */
     if(MouseClick!=-1){
     
        /** cas ou l'objet sélectionner existe dans cet endroit de l'inventaire*/
     	if(inv->sac[MouseClick]!=NULL){
     	
     		/** affichage de l'image de l'objet ainsi que ça description */
     		SDL_RenderCopy(pRenderer,inv->sac[MouseClick]->sprite,NULL,&destImage);
     		SDL_RenderCopy(pRenderer,descObj[MouseClick],NULL,&destDesc);
     		
     		/** regarde yonThrow pour gérer l'affichage du bouton jeter ainsi que ça boite d'interraction pour jeter un objet */
     		if(*yonThrow==0){
     			SDL_RenderCopy(pRenderer,buttonThrowOver,NULL,destThrowButton);
     		}
     		else if(*yonThrow>=1 && *yonThrow <=3){
     			SDL_RenderCopy(pRenderer,buttonThrow,NULL,destThrowButton);
     			SDL_RenderCopy(pRenderer,boxYoNThrow,NULL,&destBoxYoNThrow);
     		}
     		else if(*yonThrow==5){
     			jeter_obj(inv,MouseClick);
     			*yonThrow=-1;
     		}
     		
     		else{
     			SDL_RenderCopy(pRenderer,buttonThrow,NULL,destThrowButton);
     		}
     		
     		/** regarde yonUse pour gérer l'affichage du bouton utiliser ainsi que ça boite d'interraction pour selectionner un personnage 
     		* met useOk a 0 si le personnage peut utiliser cet objets sinon la met a 1
     		*/
     		if(*yonUse==0){
     			SDL_RenderCopy(pRenderer,buttonUseOver,NULL,&destUseButton);
     		}
     		else if(*yonUse>=1 && *yonUse <=4){
     			SDL_RenderCopy(pRenderer,boxYoNUse,NULL,&destBoxYoNUse);
     			for(i=0;i<3;i++){
     				SDL_QueryTexture(perso[i], NULL, NULL, &textwidth, &textheight);
     				destYoNPerso.w=textwidth;
     				if(team[i]!=NULL){
	     				if(team[i]->Pv==team[i]->PvMax && team[i]->Mana<team[i]->ManaMax){
	     					if(inv->sac[MouseClick]->valPv>0 && inv->sac[MouseClick]->valMp==0){
	     						SDL_RenderCopy(pRenderer,persoBlocked[i],NULL,&destYoNPerso);
	     						useOk[i]=1;
	     					}
	     					else{
	     						SDL_RenderCopy(pRenderer,perso[i],NULL,&destYoNPerso);
	     						useOk[i]=0;
	     					}
	     				}
	     				else if(team[i]->Pv<team[i]->PvMax && team[i]->Mana==team[i]->ManaMax){
	     					if(inv->sac[MouseClick]->valPv==0 && inv->sac[MouseClick]->valMp>0){
	     						SDL_RenderCopy(pRenderer,persoBlocked[i],NULL,&destYoNPerso);
	     						useOk[i]=1;
	     					}
	     					else{
	     						SDL_RenderCopy(pRenderer,perso[i],NULL,&destYoNPerso);
	     						useOk[i]=0;
	     					}
	     				}
	     				else if(team[i]->Pv==team[i]->PvMax && team[i]->Mana==team[i]->ManaMax){
	     					SDL_RenderCopy(pRenderer,persoBlocked[i],NULL,&destYoNPerso);
	     					useOk[i]=1;
	     				}
	     				else{
	     					SDL_RenderCopy(pRenderer,perso[i],NULL,&destYoNPerso);
	     					useOk[i]=0;
	     				}
	     			}
	     			else{
	     				SDL_RenderCopy(pRenderer,perso[i],NULL,&destYoNPerso);
	     				useOk[i]=1;
	     			}
     				
     				destYoNPerso.y+=destYoNPerso.h*2;
     			}
     			SDL_RenderCopy(pRenderer,buttonUse,NULL,&destUseButton);
     		}
     		
     		/** regarde si un personnage a été sélectionner */
     		else if(*yonUse>4){
     			utiliser_obj(inv,team[*yonUse-5],MouseClick);
     			*yonUse=-1;
     		}
     		else{
     			SDL_RenderCopy(pRenderer,buttonUse,NULL,&destUseButton);
     		}
     		
     	}
     	
     	/** cas ou l'objet sélectionner n'existe pas dans cet endroit de l'inventaire*/
     	else{
     		SDL_RenderCopy(pRenderer,descObj[MouseClick],NULL,&destNoDesc);
     	}
     	
     }
     
     /** destruction des textures utiliser pour le menu */
     SDL_DestroyTexture(objOver); 
     SDL_DestroyTexture(objClick);
     SDL_DestroyTexture(menu);
     
     /** destruction des textures utiliser pour le bouton jeter et ça boite */
     SDL_DestroyTexture(buttonThrow);
     SDL_DestroyTexture(buttonThrowOver);
     SDL_DestroyTexture(boxYoNThrow);
     
     /** destruction des textures utiliser pour le bouton utiliser et ça boite */
     SDL_DestroyTexture(buttonUse);
     SDL_DestroyTexture(buttonUseOver);
     SDL_DestroyTexture(boxYoNUse);
     
     /** destruction des textures des noms et descriptions des objets */
     for(i=0;i<10;i++){
     	SDL_DestroyTexture(nomObj[i]);
     	SDL_DestroyTexture(descObj[i]);
     }
     
     /** destruction des textures des noms,pv et pm des personnages */
     for(i=0;i<3;i++){
     	SDL_DestroyTexture(perso[i]);
     	SDL_DestroyTexture(persoBlocked[i]);
     }
     
     /** delais d'affichage */
     SDL_Delay(35);
}

/**
* fonction DetectEventsStats qui s'occupera de gérer la détection
* des évènement quand nous somme sur le menu des stats des personnages 
*/
void DetectEventsStats(int *numPage,int *MouseClick,int *MouseOver, int* quit, scene_t* scene,int w,int h,SDL_Rect *destStatAction,team_t * team,float Stats[3][8]){
    /** création de la variable event qui récupère les évènements */
    SDL_Event event;
    *MouseClick=-1;
    
    /** boucle d'attente d'évènements */
    while (SDL_PollEvent(&event) != 0) {
    
    	  /** regarde le bouton pour quitter la fenètre si appuyer met quit a 1 ce qui va arrêter la boucle de jeux */
    	  switch(event.type){
		  case SDL_QUIT:*quit = 1;break;
		  
		  /** récuperation des touche enfoncer */
		  case SDL_KEYDOWN:
		  /** regarde qu'elle touche est enfoncer */  
		  	switch(event.key.keysym.sym){
			       case SDLK_t: 
			       	     Stats[*numPage][0]=team->team[*numPage]->PvMax;
					     Stats[*numPage][1]=team->team[*numPage]->ManaMax;
					     Stats[*numPage][2]=team->team[*numPage]->For;
					     Stats[*numPage][3]=team->team[*numPage]->Def;
					     Stats[*numPage][4]=team->team[*numPage]->Int;
					     Stats[*numPage][5]=team->team[*numPage]->Res;
					     Stats[*numPage][6]=team->team[*numPage]->Vit;
					     Stats[*numPage][7]=team->team[*numPage]->PtComp;
			       	     *scene=OP ;
			       	     *MouseClick=-1;break;
		  	};break;
		  	
		  /** récuperation des coordonnées de la sourits */
		  case SDL_MOUSEMOTION:
		  	if (event.motion.y >= destStatAction[0].y && event.motion.y <= destStatAction[0].y+destStatAction[0].h){
		  		if(event.motion.x>=destStatAction[0].x && event.motion.x<=destStatAction[0].x+destStatAction[0].w){
		  			*MouseOver=16;
		  		}
		  		else if(event.motion.x>=destStatAction[0].x-destStatAction[0].w*2 && event.motion.x<=destStatAction[0].x-destStatAction[0].w){
		  			*MouseOver=15;
		  		}
		  		else if(event.motion.x>=destStatAction[0].x-destStatAction[0].w*7 && event.motion.x<=destStatAction[0].x-destStatAction[0].w*3){
		  			*MouseOver=14;
		  		}
		  		else{
		  			*MouseOver=-1;
		  		}
		  	}
		  	else if(event.motion.x >= destStatAction[1].x-destStatAction[1].h*1.5 && event.motion.x <= destStatAction[1].x-destStatAction[1].h*1.5+destStatAction[1].h){
		  		if(event.motion.y>=destStatAction[1].y && event.motion.y<=destStatAction[1].y+destStatAction[1].h){
		  			*MouseOver=6;
		  		}
		  		else if(event.motion.y>=destStatAction[1].y-destStatAction[1].h*1.5 && event.motion.y<=destStatAction[1].y-destStatAction[1].h/2){
		  			*MouseOver=5;
		  		}
		  		else if(event.motion.y>=destStatAction[1].y-destStatAction[1].h*1.5*2 && event.motion.y<=destStatAction[1].y-destStatAction[1].h*2){
		  			*MouseOver=4;
		  		}
		  		else if(event.motion.y>=destStatAction[1].y-destStatAction[1].h*1.5*3 && event.motion.y<=destStatAction[1].y-destStatAction[1].h*3.5){
		  			*MouseOver=3;
		  		}
		  		else if(event.motion.y>=destStatAction[1].y-destStatAction[1].h*1.5*4 && event.motion.y<=destStatAction[1].y-destStatAction[1].h*5){
		  			*MouseOver=2;
		  		}
		  		else if(event.motion.y>=destStatAction[1].y-destStatAction[1].h*1.5*5 && event.motion.y<=destStatAction[1].y-destStatAction[1].h*6.5){
		  			*MouseOver=1;
		  		}
		  		else if(event.motion.y>=destStatAction[1].y-destStatAction[1].h*1.5*6 && event.motion.y<=destStatAction[1].y-destStatAction[1].h*8){
		  			*MouseOver=0;
		  		}
		  		else {
		  			*MouseOver=-1;
		  		}
		  	}
		  	else if(event.motion.x >= destStatAction[1].x && event.motion.x <= destStatAction[1].x+destStatAction[1].h){
		  		if(event.motion.y>=destStatAction[1].y && event.motion.y<=destStatAction[1].y+destStatAction[1].h){
		  			*MouseOver=13;
		  		}
		  		else if(event.motion.y>=destStatAction[1].y-destStatAction[1].h*1.5 && event.motion.y<=destStatAction[1].y-destStatAction[1].h/2){
		  			*MouseOver=12;
		  		}
		  		else if(event.motion.y>=destStatAction[1].y-destStatAction[1].h*1.5*2 && event.motion.y<=destStatAction[1].y-destStatAction[1].h*2){
		  			*MouseOver=11;
		  		}
		  		else if(event.motion.y>=destStatAction[1].y-destStatAction[1].h*1.5*3 && event.motion.y<=destStatAction[1].y-destStatAction[1].h*3.5){
		  			*MouseOver=10;
		  		}
		  		else if(event.motion.y>=destStatAction[1].y-destStatAction[1].h*1.5*4 && event.motion.y<=destStatAction[1].y-destStatAction[1].h*5){
		  			*MouseOver=9;
		  		}
		  		else if(event.motion.y>=destStatAction[1].y-destStatAction[1].h*1.5*5 && event.motion.y<=destStatAction[1].y-destStatAction[1].h*6.5){
		  			*MouseOver=8;
		  		}
		  		else if(event.motion.y>=destStatAction[1].y-destStatAction[1].h*1.5*6 && event.motion.y<=destStatAction[1].y-destStatAction[1].h*8){
		  			*MouseOver=7;
		  		}
		  		else {
		  			*MouseOver=-1;
		  		}
		  	}
		  	
		  	else{
		  		*MouseOver=-1;
		  	};break;
		  /** regarde si la sourit est dans la case + ou - d'une stats */
			  
		   /** récuperation si le bouton de la sourit est lacher */
		   case SDL_MOUSEBUTTONUP:
		   /** regarde si le bouton est relacher sur une zone d'objet de l'inventaire */
		   	*MouseClick=*MouseOver;
		   	switch(*MouseOver){
		   	        case 14:
		   	        	team->team[*numPage]->PvMax=Stats[*numPage][0];
					team->team[*numPage]->ManaMax=Stats[*numPage][1];
					team->team[*numPage]->For=Stats[*numPage][2];
					team->team[*numPage]->Def=Stats[*numPage][3];
					team->team[*numPage]->Int=Stats[*numPage][4];
					team->team[*numPage]->Res=Stats[*numPage][5];
					team->team[*numPage]->Vit=Stats[*numPage][6];
					team->team[*numPage]->PtComp=Stats[*numPage][7];
		   		case 15: 
		   			Stats[*numPage][0]=team->team[*numPage]->PvMax;
					Stats[*numPage][1]=team->team[*numPage]->ManaMax;
					Stats[*numPage][2]=team->team[*numPage]->For;
					Stats[*numPage][3]=team->team[*numPage]->Def;
					Stats[*numPage][4]=team->team[*numPage]->Int;
					Stats[*numPage][5]=team->team[*numPage]->Res;
					Stats[*numPage][6]=team->team[*numPage]->Vit;
					Stats[*numPage][7]=team->team[*numPage]->PtComp;
		   			*numPage-=1;break;
		   		case 16: 
		   			Stats[*numPage][0]=team->team[*numPage]->PvMax;
					Stats[*numPage][1]=team->team[*numPage]->ManaMax;
					Stats[*numPage][2]=team->team[*numPage]->For;
					Stats[*numPage][3]=team->team[*numPage]->Def;
					Stats[*numPage][4]=team->team[*numPage]->Int;
					Stats[*numPage][5]=team->team[*numPage]->Res;
					Stats[*numPage][6]=team->team[*numPage]->Vit;
					Stats[*numPage][7]=team->team[*numPage]->PtComp;
		   			*numPage+=1;break;
		   	};break;
		   			   
          }      
    }
}

/**
* fonction ReactEventsInvSac qui s'occupe de réagire en fonction 
* des évènement quand nous somme sur le menu d'inventaire sur le sac 
*/
void ReactEventsStats(int numPage,int MouseClick, int KeyIsPressed,int MouseOver,SDL_Renderer* pRenderer,SDL_Texture* Perso,SDL_Texture* pPnj,SDL_Texture* pBlock,SDL_Rect* marcheHori,SDL_Rect* dest,SDL_Rect* block,SDL_Rect* pnj,int w,int h,team_t * team,float Stats[3][8],SDL_Rect* destStatAction){

     /** declaration de i servant au boucle for et textwidth, textheight pour les dimensions des textes */
     int i,j, textwidth, textheight;
     
     /** chaine de caractère utiliser pour l'affichage des persos avec leur stats  */
     char nomStat[8][20]={"Vie: ","Mana: ","Force: ","Defense: ","Intelligence: ","Resistance: ","Vitesse: ","PT de competence: "};
     char valStat[8][4];
     char stat[21];
     char lvl[2];
     char nomlvl[28];
     
     /** stat stocker temporairement pour vérifier certaine condition pour pouvoir utiliser le bouton + et - */
     int statTempo[3][8];
     for(j=0;j<team->nbPerso;j++){
		statTempo[j][0]=team->team[j]->PvMax;
		statTempo[j][1]=team->team[j]->ManaMax;
		statTempo[j][2]=team->team[j]->For;
		statTempo[j][3]=team->team[j]->Def;
		statTempo[j][4]=team->team[j]->Int;
		statTempo[j][5]=team->team[j]->Res;
		statTempo[j][6]=team->team[j]->Vit;
		statTempo[j][7]=team->team[j]->PtComp;
     }
     
     /** chargement des textures nécessaire aux menu */
     SDL_Texture* menu=loadTexture("../Ressource/MenuStat.png",pRenderer);
     SDL_Texture* boutonValider=NULL;
     
     SDL_Texture* inc=NULL;
     
     SDL_Texture* dec=NULL;
     
     SDL_Texture* arrow=NULL;
     
     /** declaration des rect correspondant au coordonnées et dimensions d'affichage du menu */
     int temp=w/5+((w/2)/94)*2.8;
     SDL_Rect destMenu={w-w/2,h-h/2,w/2,h/2};
     SDL_Rect destzone={(w-w/2)+((w/2)/94)*3,(h-h/2)+((h/2)/5)-2,(w/4),((h/2)-((h/2)/5)-2)/9.5};
     
     
     /** declaration et initialisation des textures des noms et descriptions des objets ainsi que la couleur des texte */
     SDL_Color blanc={255,255,255};
     SDL_Color gris={195,195,195};
     
     
     /** déclaration et initialisation des texture des textes des personnages dans la boite d'utilisation d'objet*/
     SDL_Texture* allStat[3][8];
     for(j=0;j<team->nbPerso;j++){
	     for(i=0;i<8;i++){
	     	if(team->team[j]!=NULL){
	     		strcpy(stat,nomStat[i]);
	     		sprintf(valStat[i],"%.0f",Stats[j][i]);
	     		strcat(stat,valStat[i]);
	     		allStat[j][i]=loadTextureFont("../Ressource/font/BlockKie.ttf",pRenderer,stat,((h/2)-((h/2)/5)-2)/9.5,blanc);
	     	}
	     }
     }
     
     /** declaration de la variable pour les coordonnées et dimensions des noms d'objets */
     SDL_Rect destStat;
     
     /** nettoyage de l'écran puis affichage de l'écran actuel ou l'on est dans l'open world*/
     SDL_RenderClear(pRenderer);/** nettoyage de l'écran */
     SDL_RenderCopy(pRenderer,pPnj,NULL,pnj); /** placemet de la map */
     SDL_RenderCopy(pRenderer,pBlock,NULL,block);/** placement d'un block de collision */
     switch(KeyIsPressed){
        case 0:SDL_RenderCopy(pRenderer,Perso,marcheHori+0,dest);break;
        
        case -1:SDL_RenderCopyEx(pRenderer,Perso,marcheHori+0,dest, 0, NULL, SDL_FLIP_HORIZONTAL);break;
        
        case -3:SDL_RenderCopy(pRenderer,Perso,marcheHori+0,dest);break;
        
        case -2:SDL_RenderCopyEx(pRenderer,Perso,marcheHori+0,dest, 0, NULL, SDL_FLIP_HORIZONTAL);break;
     }
     
     /** affichage du menu */
     SDL_RenderCopy(pRenderer,menu,NULL,&destMenu);
     
     /** création de la texture du nom du perso avec son level */
     sprintf(lvl,"%d",team->team[numPage]->lvl);
     strcpy(nomlvl,team->team[numPage]->Nom);
     strcat(nomlvl," lvl: ");
     strcat(nomlvl,lvl);
     SDL_Texture* nomPerso=loadTextureFont("../Ressource/font/BlockKie.ttf",pRenderer,nomlvl,((h/2)-((h/2)/5)-2)/9.5,blanc);
     
     /** calcul des coordonnées et dimensions du nom du perso avec son lvl */
     SDL_QueryTexture(nomPerso, NULL, NULL, &textwidth, &textheight);
     destStat.x=w/4-textheight/2;
     destStat.x*=3;
     destStat.y=destzone.y-destzone.y/30;
     destStat.w=textwidth;
     destStat.h=textheight;
     
     /** affichage du nom du perso avec son lvl puis libère la mémoire */
     SDL_RenderCopy(pRenderer,nomPerso,NULL,&destStat);
     SDL_DestroyTexture(nomPerso);
     
     destzone.y+=destStat.h/2;
     for(i=0;i<7;i++){
        
        /** calcul des coordonnées, dimensions des bouton + et - */
     	destStat.x=(w/4)*3;
     	destStat.y=destzone.y;
     	destStat.w=textheight/1.5;
     	destStat.h=destStat.w;
     	destStat.y+=destStat.h/2;
     	
     	/** chargement de la texture puis affichage du boutons + en on ou off en fonction de si l'on peut utiliser les bouton ou non
     	*  pour eviter de dépasser le nombre de pt de compétences a utiliser enfin libère la mémoire
     	*/
     	if(Stats[numPage][7]<=0){
     		inc=loadTexture("../Ressource/statIncOff.png",pRenderer);
     		SDL_RenderCopy(pRenderer,inc,NULL,&destStat);
     	}
     	else{
     		if(MouseOver==i){
     			inc=loadTexture("../Ressource/statIncOver.png",pRenderer);
     		}
     		else{
     			inc=loadTexture("../Ressource/statIncOn.png",pRenderer);
     		}
     		SDL_RenderCopy(pRenderer,inc,NULL,&destStat);
     		if(MouseClick==i){
     			Stats[numPage][i]+=1;
     			Stats[numPage][7]-=1;
     		}
     	}
     	SDL_DestroyTexture(inc);
     	
     	/** chargement de la texture puis affichage du boutons - en on ou off en fonction de si l'on peut utiliser les bouton ou non
     	*  pour eviter de diminuer en dessous des stats de base enfin libère la mémoire
     	*/
     	destStat.x+=textheight;
     	if(Stats[numPage][7]==team->team[numPage]->PtComp || Stats[numPage][i]==statTempo[numPage][i]){
     		dec=loadTexture("../Ressource/statDecOff.png",pRenderer);
     		SDL_RenderCopy(pRenderer,dec,NULL,&destStat);
     	}
     	else{
     		if(MouseOver==i+7){
     			dec=loadTexture("../Ressource/statDecOver.png",pRenderer);
     		}
     		else{
     			dec=loadTexture("../Ressource/statDecOn.png",pRenderer);
     		}
     		SDL_RenderCopy(pRenderer,dec,NULL,&destStat);
     		
     		if(MouseClick==i+7){
     			Stats[numPage][i]-=1;
     			Stats[numPage][7]+=1;
     		}
     	}
     	SDL_DestroyTexture(dec);
     	
     	/** récupère les dernières coordonnées des boutons + et - pour la detection d'évents */
     	destStatAction[1].x=destStat.x;
     	destStatAction[1].y=destStat.y;
     	destStatAction[1].w=destStat.w;
     	destStatAction[1].h=destStat.h;
     	
     	/** mise a jour des coordonnées et dimensions des stats */
     	SDL_QueryTexture(allStat[numPage][i], NULL, NULL, &textwidth, &textheight);
     	destStat.x=destzone.x;
     	destStat.y=destzone.y;
     	destStat.w=textwidth;
     	destStat.h=textheight;
     	
     	/** affichage des stats */
     	SDL_RenderCopy(pRenderer,allStat[numPage][i],NULL,&destStat);
     	destzone.y+=destStat.h;
     }
     
     /** calcul des coordonnées, dimensions des points de compétences du personnage sur lequel on est */
     SDL_QueryTexture(allStat[numPage][i], NULL, NULL, &textwidth, &textheight);
     destStat.x=destzone.x;
     destStat.y=h-1.5*textheight;
     destStat.w=textwidth;
     destStat.h=textheight;
     
     /** affichage des points de compétences du personnage */
     SDL_RenderCopy(pRenderer,allStat[numPage][7],NULL,&destStat);
     
     /** calculdes coordonnées, dimensions, charge les textures plus affichage du bouton valider pour confirmer les points de compétences attribuer */
     destStat.x+=textwidth*1.25;
     destStat.w=textwidth/2;
     if(statTempo[numPage][7]==0 || Stats[numPage][7]==statTempo[numPage][i]){
        SDL_Texture* boutonValider=loadTexture("../Ressource/validButtonOver.png",pRenderer);
     	SDL_RenderCopy(pRenderer,boutonValider,NULL,&destStat);
     }
     else{
     	if(MouseOver==14){
     		SDL_Texture* boutonValider=loadTexture("../Ressource/validButtonOver.png",pRenderer);
     		SDL_RenderCopy(pRenderer,boutonValider,NULL,&destStat);
     	}
     	else{
     		SDL_Texture* boutonValider=loadTexture("../Ressource/validButton.png",pRenderer);
     		SDL_RenderCopy(pRenderer,boutonValider,NULL,&destStat);
     	}
     }
     
     /** calculdes coordonnées, dimensions de la flèches gauche pour changer de perso */
     destStat.x+=destStat.w*1.25;
     destStat.w=destStat.w/4;
     destStat.h=destStat.w;
     
     /** affichage des flèches pour changer de perso si la sourit est dessus assombris le bouton 
     *  si nous ommes sur le premiers perso on affiche pass la flèche vers la gauche et 
     *  si on est sur le dernier perso la flèche de droite n'est pas afficher
     *  puis libère la mémoire
     */
     if(numPage>0){
     	if(MouseOver==15){
     		arrow=loadTexture("../Ressource/leftOver.png",pRenderer);
     	}
     	else{
     		arrow=loadTexture("../Ressource/left.png",pRenderer);
     	}
     	SDL_RenderCopy(pRenderer,arrow,NULL,&destStat);
     	SDL_DestroyTexture(arrow);
     }
     
     /** calculdes coordonnées, dimensions de la flèches droite pour changer de perso puis libère la mémoire */
     destStat.x+=destStat.w*2;
     if(numPage<team->nbPerso-1){
     	if(MouseOver==16){
     		arrow=loadTexture("../Ressource/rightOver.png",pRenderer);
     	}
     	else{
     		arrow=loadTexture("../Ressource/right.png",pRenderer);
     	}
     	SDL_RenderCopy(pRenderer,arrow,NULL,&destStat);
     	SDL_DestroyTexture(arrow);
     }
     
     /** copie des coordonnées des derniers outon pour les detection d'évents */
     destStatAction[0].x=destStat.x;
     destStatAction[0].y=destStat.y;
     destStatAction[0].w=destStat.w;
     destStatAction[0].h=destStat.h;
     
     
     /** destruction des textures utiliser pour le menu */
     SDL_DestroyTexture(menu);
     
     /** destruction des textures des noms et descriptions des objets */
     for(j=0;j<team->nbPerso;j++){
	     for(i=0;i<8;i++){
	     	SDL_DestroyTexture(allStat[j][i]);
	     }
     }
     
     /** destruction de toutes les textures des bouton */
     SDL_DestroyTexture(arrow);
     
     SDL_DestroyTexture(boutonValider);
     
     SDL_DestroyTexture(inc);
     
     SDL_DestroyTexture(dec);
     
     /** delais d'affichage */
     SDL_Delay(35);
}
