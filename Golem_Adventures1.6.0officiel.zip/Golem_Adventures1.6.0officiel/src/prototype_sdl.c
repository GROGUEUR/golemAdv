#include <stdio.h>
#include <stdlib.h>
#include "../lib/EventOp.h"
#include "../lib/texture.h"
#include "../lib/type.h"
#include "../lib/init_menu.h"

int main(int argc, char** argv){
    /** initialisation de x pour les coordonnée src et i pour les boucles  
    * ainsi que de w et h pour récupérer la longueur et largeur de la fenètre
    */
    int i,x=0;
    int w=0,h=0;
    
    /** Initialisation de SDL pour les VIDEO, EVENTS et AUDIO */
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_EVENTS | SDL_INIT_AUDIO) != 0 ){
        fprintf(stdout,"Échec de l'initialisation de la SDL (%s)\n",SDL_GetError());
        return -1;
    }

    else{
    
        /** Création de la fenêtre */
        SDL_Window* pWindow = NULL;
        pWindow = SDL_CreateWindow("Ma première application SDL2",SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED,1360,780,SDL_WINDOW_SHOWN);
        SDL_GetWindowSize(pWindow,&w,&h);
        
        /** Initialisation de SDL_IMAGE */
        if (IMG_Init(IMG_INIT_PNG) != IMG_INIT_PNG) {
        	fprintf(stderr, "Erreur d'initialisation de SDL_image : %s\n", IMG_GetError());
        	SDL_Quit();
        	return 1;
    	}
    	
    	/** Initialisation de SDL_TTF */
    	if (TTF_Init() < 0) {
                fprintf(stderr, "Erreur d'initialisation de SDL_ttf : %s\n", TTF_GetError());
                IMG_Quit();
                SDL_Quit();
                return 1;
        }
        
        /** Initialisation de SDL_Mixer */
    	if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0) {
        	SDL_Log("Erreur lors de l'initialisation de SDL_mixer : %s", Mix_GetError());
        	IMG_Quit();
        	TTF_Quit();
        	SDL_Quit();
        	return 1;
        }
        
        if( pWindow )
        {
            /** Création d'un SDL_Renderer utilisant l'accélération matérielle */
            SDL_Renderer *pRenderer = SDL_CreateRenderer(pWindow,-1,SDL_RENDERER_ACCELERATED);
            if ( pRenderer )
            {
		    /** chargement des texture  du perso, etc ...*/
		    SDL_Texture* pPerso=loadTexture("../Ressource/scorpion.png",pRenderer);
		    SDL_Texture* pSol=loadTexture("../Ressource/navigateZone.png",pRenderer);
		    SDL_Texture* pBlock=loadTexture("../Ressource/blockZone.png",pRenderer);
		    SDL_Texture* pPnj=loadTexture("../Ressource/pnj.png",pRenderer);
                    if ( pPerso != NULL && pSol != NULL)
                    {
                        /** déclaration des destination du perso, map, block et pnj ainsi que des variable pour la music */
                        SDL_Rect dest = { w/2 - 64/2,h/2 - 64/2, 64,64};
                        SDL_Rect map = { 0,0, w,h};
                        SDL_Rect block = { w-280,h/2, 64,256};
                        SDL_Rect pnj = { w-280,(h/2)-64, 64,64};
                        Mix_Music * backMenu = NULL;
                        Mix_Music * backOp = NULL;
                        Mix_Music * backP = NULL;
                        
                        /**
                        * création et initialisation d'un tableau selectionnant tout les sprites de l'animation de marche
                        */
                        SDL_Rect marcheHori[6];
                        for (i=0;i<6;i++){
                            marcheHori[i].x=x;
                            marcheHori[i].y=0;
                            marcheHori[i].w=32;
                            marcheHori[i].h=32;
                            x+=32;
                        }
             
                        /**
                        * déclaration de quitOp et quitMenu etant les variables booleennes qui mettent fin respectivement a la boucle de l'open world et des menus
                        * déclaration keyPressed pour gérer les touches
                        * déclaration Action pour les interraction
                        * déclaration MouseHover, Mouseclick pour gérer la sourit
                        * déclaration yonThrow gérant la boite d'interraction pour jeter un objet
                        * déclaration yonUse gérant la boite d'interraction pour utiliser un objet
                        * déclaration tableau useOk etant a 1 si l'objet n'est pas utilisable sur un personnage sinon a 0
                        */
                        int quitOp, quitMenu = 0, KeyIsPressed=0, Action=0,MouseOver=-1,MouseClick=-1,yonThrow=-1, yonUse=-1;
                        int numPage=0;
                        int choixMenuPr = NOTHING, choixMenuPlay = NOTHING, choixMenuPause = NOTHING;
                        int useOk[3];
                        useOk[0]=1;
                        useOk[1]=1;
                        useOk[2]=1;
                        
                        /** déclaration de la scene ou est le jeu */
                        scene_t scene=OP;
                        
                        /** création de tout les objets du jeux */
                        objet_t allPot[ALL_OBJETS];
                        creer_all_objet(allPot,pRenderer);
                        
                        
                        /** création de tout les équipements du jeux en 3 fois,
                        * pour éviter d'avoir le même équipement sur plusieurs perso
                        */
                        equipement_t allStuff[ALL_EQUIPEMENTS][3];
                        SDL_Texture* allSpriteStuff[ALL_EQUIPEMENTS];
                        creer_all_sprite_equipement(allSpriteStuff,pRenderer);
                        creer_all_equipement(allStuff,allSpriteStuff);
                        
                        /** création de tou les personnage possible */
                        perso_t allPerso[NB_TEAM_PERSOS];
                        float statsPerso[NB_TEAM_PERSOS][8];
                        creer_perso(&allPerso[0],"Golemete","Golem",pRenderer,statsPerso[0]);
                        creer_perso(&allPerso[1],"asdael","Mage",pRenderer,statsPerso[1]);
                        creer_perso(&allPerso[2],"La bete","Guerrier",pRenderer,statsPerso[2]);
                        
                        /** déclaration de l'équipe en jeux pour tester */
                        team_t team;
                        init_reinit__team(&team);
                        join_team(&team,allPerso);
                        join_team(&team,allPerso);
                        join_team(&team,allPerso);
                        statsPerso[0][7]=team.team[0]->PtComp=5;
                        SDL_Rect destStatAction[2];
                        
                        /** déclaration et initialisation de l'inventaire */
                        inventaire_t inventaire;
                        init_and_reinit_inv(&inventaire);
                        ajouter_obj(&inventaire,allPot,0);
                        ajouter_obj(&inventaire,allPot,8);
                        ajouter_obj(&inventaire,allPot,3);
                        SDL_Rect destThrowButton;
                        
                        /** ajoute de l'équipements dans l'inventaire pour tester */
                        ajouter_stuff(allStuff,&inventaire,25);
                        ajouter_stuff(allStuff,&inventaire,18);
                        ajouter_stuff(allStuff,&inventaire,0);
                        ajouter_stuff(allStuff,&inventaire,9);
                        
                        /** équipe les persos avec le stuff voulu pour tester */
               	 equiper_stuff(inventaire.equipements[0],team.team[0]);
               	 equiper_stuff(inventaire.equipements[2],team.team[1]);
               	 equiper_stuff(inventaire.equipements[2],team.team[0]);
               	 
               	 /** déséquipe et jete un équipement pour tester */
               	 desequiper_stuff(3,team.team[0]);
               	 jeter_stuff(&inventaire,2);
                        
                        i=0;
			/** boucle entière du jeu */
			while(quitMenu != NOTHING){
				quitOp = 0;
				/** boucle menu */
				while(quitMenu == 0){
					if(backMenu==NULL){
						printf("ok\n");
						if(backP!=NULL){
							Mix_FreeMusic(backP);
							backP=NULL;
						}
						backMenu = Mix_LoadMUS("../Ressource/menu.mp3");
						Mix_PlayMusic(backMenu, -1);
					}
					switch(choixMenuPr = menuPrincipal(pRenderer)){
						case PLAY:
							choixMenuPlay = menuPlay(pRenderer);
							if((choixMenuPlay - (choixMenuPlay % 10)) == SAVE1){
								quitMenu = 1;
								if(choixMenuPlay % 10 == LOAD){
									/** Placer la fonction de chargement de la sauvegarde ici */
								}
								else if(choixMenuPlay % 10 == NEWGAME){
									/** Placer la fonction de création de la sauvegarde ici */
								}
								scene = OP;
							}
							else if((choixMenuPlay - (choixMenuPlay % 10)) == SAVE2){
								quitMenu = 1;
								if(choixMenuPlay % 10 == LOAD){
									/** Placer la fonction de chargement de la sauvegarde ici */
								}
								else if(choixMenuPlay % 10 == NEWGAME){
									/** Placer la fonction de création de la sauvegarde ici */
								}
								scene = OP;
							}
							else if((choixMenuPlay - (choixMenuPlay % 10)) == SAVE3){
								quitMenu = 1;
								if(choixMenuPlay % 10 == LOAD){
									/** Placer la fonction de chargement de la sauvegarde ici */
								}
								else if(choixMenuPlay % 10 == NEWGAME){
									/** Placer la fonction de création de la sauvegarde ici */
								}
								scene = OP;
							}
							else if((choixMenuPlay - (choixMenuPlay % 10)) == BACK);
							
							if(choixMenuPlay == NOTHING){
								quitMenu = NOTHING;
								quitOp = 1;
							}
							break;
						case SETTINGS:
							menuSettings(pRenderer);
							break;
						case CREDITS:
							menuCredits(pRenderer);
							break;
						case NOTHING:
							quitMenu = NOTHING;
							break;
					}
				}
				/** boucle open world */
				while (!quitOp && quitMenu != NOTHING) {
					quitMenu = 0;

					/** récupération de la longueur et de la largeur de la fenètre */
					SDL_GetWindowSize(pWindow,&w,&h);

					/** Regarde sur qu'elle scene nous sommes pour gérer les évènemnets et affichage */
					switch(scene){

						/** Open World */
						case OP:
							/** activation de la musique */
							if(backOp==NULL){
								if(backMenu!=NULL){
									Mix_FreeMusic(backMenu);
									backMenu=NULL;
								}
								else if(backP!=NULL){
									Mix_FreeMusic(backP);
									backP=NULL;
								}
								backOp = Mix_LoadMUS("../Ressource/OPZ.mp3");
								Mix_PlayMusic(backOp, -1);
							}
							/** détection des évènements */
							DetectEventsOp(&KeyIsPressed,&quitMenu,&Action,&scene);
							/** réaction aux évènements */

							ReactEventsOp(KeyIsPressed,&Action,pRenderer,pPerso,pPnj,pBlock,marcheHori,&dest,&i,&block,&pnj,w,h);
							break;

							/** Menu Pause */
						case PAUSE:
							if(backP==NULL){
								Mix_FreeMusic(backOp);
								backOp=NULL;
								backP = Mix_LoadMUS("../Ressource/Pause.mp3");
								Mix_PlayMusic(backP, -1);
							}
							switch(choixMenuPause = menuPause(pRenderer, &scene)){
								case SAVE:
									/** Appeler fonction sauvegarde */
									break;
								case SQUIT:
									/** Appeler fonction sauvegarde */
									scene = MENUP;
									quitOp = 1;
									break;
								case OPTIONS:
									menuSettings(pRenderer);
								case RESUME:
									/** réaction aux évènements */
									ReactEventsP(pRenderer,allStuff[18][2].artwork,&map);
									scene = OP;
									break;
								case NOTHING:
									quitOp = 1;
									quitMenu = -1;
									break;
							}
							break;

						/** Menu Inventaire sac */
						case INVENTORY:
							if(KeyIsPressed>0){
								KeyIsPressed*=-1;
							}
							DetectEventsInvSac(useOk,&yonUse,&yonThrow,&MouseClick,&MouseOver,&quitMenu,&scene,w,h,destThrowButton);
							ReactEventsInvSac(useOk,&yonUse,&yonThrow,MouseClick,KeyIsPressed,MouseOver,pRenderer,pPerso,pPnj,pBlock
							,marcheHori,&dest,&block,&pnj,pPnj,w,h,&inventaire,&destThrowButton,team.team);break;
						
					}

					/** Mise a jour de l'écran */
					SDL_RenderPresent(pRenderer);
				}
			}
                        
                        /** réinitialisation de l'inventaire */
                        init_and_reinit_inv(&inventaire);
                        
                        /** Libération de la mémoire associée aux Musiques */
                        Mix_FreeMusic(backOp);
                        backOp=NULL;
                        Mix_FreeMusic(backP);
                        backP=NULL;
                        
                        /** Libération de la mémoire associée aux texture */
                        SDL_DestroyTexture(pPerso); 
                        SDL_DestroyTexture(pSol);
                        SDL_DestroyTexture(pBlock);
                        SDL_DestroyTexture(pPnj);
                        for(i=0;i<ALL_OBJETS;i++){
			    	SDL_DestroyTexture(allPot[i].sprite);
			    	allPot[i].sprite=NULL;
			 }
			 for(i=0;i<ALL_EQUIPEMENTS;i++){
			    	SDL_DestroyTexture(allSpriteStuff[i]);
			    	allSpriteStuff[i]=NULL;
			 }
			 
                    }
                    else
                    {
                        fprintf(stdout,"Échec de création de la texture (%s)\n",SDL_GetError());
                    }
        
                SDL_DestroyRenderer(pRenderer); /** Libération de la mémoire du SDL_Renderer */
            }
            else
            {
                fprintf(stdout,"Échec de création du renderer (%s)\n",SDL_GetError());
            }
            SDL_Delay(1000); /** Attendre trois secondes, que l'utilisateur voie la fenêtre */
            SDL_DestroyWindow(pWindow);
        }
     else
        {
            fprintf(stderr,"Erreur de création de la fenêtre: %s\n",SDL_GetError());
        }
    }
    
    /** fermeture de toutes les extensions SDL, IMG, TTF et AUDIO */
    Mix_CloseAudio();
    TTF_Quit();
    IMG_Quit();
    SDL_Quit();
    return 0;
}

